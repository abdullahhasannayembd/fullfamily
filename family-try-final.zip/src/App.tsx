import React, { useState, useEffect, useMemo } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, onSnapshot, query, orderBy, addDoc, writeBatch, doc } from 'firebase/firestore';
import { FamilyMember, SiteSettings } from './types';
import { Auth } from './components/Auth';
import { FamilyTree } from './components/FamilyTree';
import { MemberForm } from './components/MemberForm';
import { MemberProfile } from './components/MemberProfile';
import { AdminPanel } from './components/AdminPanel';
import { 
  Plus, 
  Search, 
  TreePine, 
  Users, 
  Settings, 
  HelpCircle, 
  ChevronRight,
  Loader2,
  Menu,
  X,
  Cloud,
  CloudOff,
  RefreshCw,
  Download,
  Upload as UploadIcon,
  FileJson
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { exportToGEDCOM, parseGEDCOM } from './lib/gedcom';
import { AdComponent } from './components/AdComponent';
import { databaseService } from './services/databaseService';


export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isGoogleDriveConnected, setIsGoogleDriveConnected] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    id: 'global',
    headerTitle: 'Main Family Tree',
    familyName: 'The Family',
    footerText: '© 2024 Family Tree Explorer. All rights reserved.',
    primaryColor: '#10b981',
    accentColor: '#34d399',
    theme: 'dark',
    adsEnabled: false,
    adPosition: 'sidebar',
    autoGenerateTree: true,
    showGenerations: true,
    defaultExpandedGenerations: 3,
    publicModeEnabled: false,
    updatedAt: Date.now(),
    updatedBy: ''
  });

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthLoading(false);
      if (u) {
        try {
          await databaseService.initializeDatabase(u.uid);
        } catch (error) {
          console.error("Database initialization failed:", error);
        }
      }
    });
    return unsubscribe;
  }, []);

  // Google Drive Status
  useEffect(() => {
    const checkGoogleDriveStatus = async () => {
      try {
        const response = await fetch('/api/auth/google/status');
        const data = await response.json();
        setIsGoogleDriveConnected(data.connected);
      } catch (error) {
        console.error("Failed to check Google Drive status:", error);
      }
    };
    checkGoogleDriveStatus();

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'GOOGLE_DRIVE_AUTH_SUCCESS') {
        setIsGoogleDriveConnected(true);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Firestore Listener for Members
  useEffect(() => {
    const q = query(collection(db, 'members'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as FamilyMember[];
      setMembers(data);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  // Firestore Listener for Site Settings
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'settings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setSiteSettings(snapshot.data() as SiteSettings);
      }
    }, (error) => {
      console.error("Settings snapshot error:", error);
    });
    return unsubscribe;
  }, []);

  // Automatic Backup
  useEffect(() => {
    if (isGoogleDriveConnected && members.length > 0) {
      const timeoutId = setTimeout(() => {
        handleBackup();
      }, 5000); // Debounce backup
      return () => clearTimeout(timeoutId);
    }
  }, [members, isGoogleDriveConnected]);

  const handleBackup = async () => {
    if (!isGoogleDriveConnected) return;
    setIsBackingUp(true);
    try {
      const response = await fetch('/api/backup/google-drive', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: members }),
      });
      if (!response.ok) throw new Error('Backup failed');
      console.log("Backup successful!");
    } catch (error) {
      console.error("Backup failed:", error);
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleConnectGoogleDrive = async () => {
    try {
      const response = await fetch('/api/auth/google/url');
      const { url } = await response.json();
      window.open(url, 'google_drive_auth', 'width=600,height=700');
    } catch (error) {
      console.error("Failed to get Google Drive auth URL:", error);
    }
  };

  const handleSeedDemoData = async (isSilent = false) => {
    if (!user && !isSilent) {
      alert("Please login to seed demo data.");
      return;
    }

    if (!isSilent && !window.confirm("This will add 10 demo members with profile photos to your tree. Continue?")) {
      return;
    }

    setIsSeeding(true);
    try {
      const batch = writeBatch(db);
      const membersRef = collection(db, 'members');

      // Create IDs first for relationships
      const ggfRef = doc(membersRef); // Great Grandfather
      const ggmRef = doc(membersRef); // Great Grandmother
      const gfRef = doc(membersRef);  // Grandfather
      const gmRef = doc(membersRef);  // Grandmother
      const uncleRef = doc(membersRef);
      const fatherRef = doc(membersRef);
      const motherRef = doc(membersRef);
      const auntRef = doc(membersRef);
      const selfRef = doc(membersRef);
      const siblingRef = doc(membersRef);

      const timestamp = Date.now();
      const common = {
        createdBy: user?.uid || 'system',
        createdAt: timestamp,
        updatedAt: timestamp,
        biography: 'Demo member for testing the family tree layout.',
        status: 'approved' as const,
      };

      // 1. Great Grandfather
      batch.set(ggfRef, {
        ...common,
        fullName: 'Thomas Morgan',
        dateOfBirth: '1840-03-12',
        occupation: 'Pioneer',
        spouseId: ggmRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
      });

      // 2. Great Grandmother
      batch.set(ggmRef, {
        ...common,
        fullName: 'Sarah Morgan',
        dateOfBirth: '1842-07-15',
        occupation: 'Teacher',
        spouseId: ggfRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
      });

      // 3. Grandfather
      batch.set(gfRef, {
        ...common,
        fullName: 'Arthur Morgan II',
        dateOfBirth: '1863-05-15',
        occupation: 'Explorer',
        fatherId: ggfRef.id,
        motherId: ggmRef.id,
        spouseId: gmRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
      });

      // 4. Grandmother
      batch.set(gmRef, {
        ...common,
        fullName: 'Mary Linton',
        dateOfBirth: '1865-08-22',
        occupation: 'Botanist',
        spouseId: gfRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
      });

      // 5. Uncle
      batch.set(uncleRef, {
        ...common,
        fullName: 'Hosea Morgan',
        dateOfBirth: '1867-11-30',
        occupation: 'Strategist',
        fatherId: ggfRef.id,
        motherId: ggmRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
      });

      // 6. Father
      batch.set(fatherRef, {
        ...common,
        fullName: 'John Marston',
        dateOfBirth: '1890-03-10',
        occupation: 'Rancher',
        fatherId: gfRef.id,
        motherId: gmRef.id,
        spouseId: motherRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
      });

      // 7. Mother
      batch.set(motherRef, {
        ...common,
        fullName: 'Abigail Marston',
        dateOfBirth: '1892-11-04',
        occupation: 'Homestead Manager',
        spouseId: fatherRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
      });

      // 8. Aunt
      batch.set(auntRef, {
        ...common,
        fullName: 'Sadie Morgan',
        dateOfBirth: '1895-02-14',
        occupation: 'Bounty Hunter',
        fatherId: gfRef.id,
        motherId: gmRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=400&fit=crop',
      });

      // 9. Self
      batch.set(selfRef, {
        ...common,
        fullName: 'Jack Marston',
        dateOfBirth: '1915-06-25',
        occupation: 'Writer',
        fatherId: fatherRef.id,
        motherId: motherRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=400&fit=crop',
      });

      // 10. Sibling
      batch.set(siblingRef, {
        ...common,
        fullName: 'Elizabeth Marston',
        dateOfBirth: '1918-09-12',
        occupation: 'Artist',
        fatherId: fatherRef.id,
        motherId: motherRef.id,
        photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=400&fit=crop',
      });

      await batch.commit();
      if (!isSilent) alert("Successfully seeded 10 demo members!");
    } catch (error) {
      console.error("Error seeding demo data:", error);
      if (!isSilent) alert("Failed to seed demo data.");
    } finally {
      setIsSeeding(false);
    }
  };

  // Automatic Seeding if empty
  useEffect(() => {
    if (!loading && members.length === 0 && !isSeeding) {
      handleSeedDemoData(true);
    }
  }, [loading, members.length, isSeeding]);

  const handleExportGEDCOM = () => {
    if (members.length === 0) {
      alert("No members to export.");
      return;
    }
    const gedcom = exportToGEDCOM(members);
    const blob = new Blob([gedcom], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `family_tree_${new Date().toISOString().split('T')[0]}.ged`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportGEDCOM = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setIsImporting(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      const parsedMembers = parseGEDCOM(content);

      if (parsedMembers.length === 0) {
        alert("No valid members found in the GEDCOM file.");
        setIsImporting(false);
        return;
      }

      if (window.confirm(`Found ${parsedMembers.length} members. Import them all?`)) {
        try {
          const batch = writeBatch(db);
          parsedMembers.forEach((m) => {
            const newDocRef = doc(collection(db, 'members'));
            batch.set(newDocRef, {
              ...m,
              createdBy: user.uid,
              createdAt: Date.now(),
              updatedAt: Date.now(),
              photoUrl: '',
            });
          });
          await batch.commit();
          alert(`Successfully imported ${parsedMembers.length} members.`);
        } catch (err) {
          console.error("Import error:", err);
          alert("Failed to import members. Check console for details.");
        }
      }
      setIsImporting(false);
    };
    reader.readAsText(file);
  };

  const visibleMembers = useMemo(() => {
    // Admins see everything, public only sees approved
    if (user) return members;
    return members.filter(m => m.status === 'approved' || !m.status);
  }, [members, user]);

  const filteredMembers = useMemo(() => {
    return visibleMembers.filter(m => 
      m.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.occupation?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [visibleMembers, searchQuery]);

  const handleAddMember = () => {
    if (!user && !siteSettings.publicModeEnabled) {
      alert("Please login to add family members.");
      return;
    }
    setEditingMember(null);
    setIsFormOpen(true);
  };

  const handleEditMember = (member: FamilyMember) => {
    setEditingMember(member);
    setIsFormOpen(true);
  };

  if (authLoading) {
    return (
      <div className="h-screen w-full bg-zinc-950 flex items-center justify-center">
        <Loader2 style={{ color: siteSettings.primaryColor }} className="animate-spin" size={48} />
      </div>
    );
  }

  return (
    <div className={cn(
      "h-screen w-full flex overflow-hidden font-sans transition-colors duration-500",
      siteSettings.theme === 'light' ? "bg-zinc-50 text-zinc-900" : "bg-[#050505] text-zinc-100"
    )} style={{ '--tw-selection-bg': `${siteSettings.primaryColor}4d` } as any}>
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 340 : 0, opacity: isSidebarOpen ? 1 : 0 }}
        className={cn(
          "h-full backdrop-blur-3xl border-r transition-all relative z-30 flex flex-col",
          siteSettings.theme === 'light' ? "bg-white/80 border-zinc-200" : "bg-black/40 border-white/5"
        )}
      >
        <div className={cn(
          "p-8 flex items-center gap-4 border-b transition-all",
          siteSettings.theme === 'light' ? "bg-zinc-100/50 border-zinc-200" : "bg-white/[0.02] border-white/5"
        )}>
          <div className="p-3 rounded-xl border shadow-[0_0_30px_rgba(16,185,129,0.1)]" style={{ backgroundColor: `${siteSettings.primaryColor}1a`, borderColor: `${siteSettings.primaryColor}33` }}>
            <TreePine style={{ color: siteSettings.primaryColor }} size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tighter text-white leading-none font-serif italic">AncestryFlow</h1>
            <p className="text-[10px] font-bold uppercase tracking-widest mt-1.5 opacity-50" style={{ color: siteSettings.primaryColor }}>Family Heritage</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-10 custom-scrollbar">
          {/* Search */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">Directory</label>
              <div className="w-8 h-[1px] bg-white/10" />
            </div>
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600 transition-colors group-focus-within:text-white" size={16} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Find a relative..."
                className="w-full pl-11 pr-4 py-3 bg-white/[0.03] border border-white/5 rounded-xl text-sm focus:outline-none focus:border-white/20 transition-all placeholder:text-zinc-700"
              />
            </div>
          </div>

          {/* Cloud Status */}
          <div className="space-y-4">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Cloud Sync</label>
            <button
              onClick={handleConnectGoogleDrive}
              className={cn(
                "w-full flex items-center gap-4 p-4 rounded-xl border transition-all group",
                isGoogleDriveConnected 
                  ? "bg-white/[0.03] border-white/10" 
                  : "bg-white/[0.01] border-white/5 hover:bg-white/[0.03] text-zinc-500"
              )}
            >
              <div className={cn(
                "p-2 rounded-lg transition-colors",
                isGoogleDriveConnected ? "bg-emerald-500/10 text-emerald-500" : "bg-white/5 text-zinc-600"
              )}>
                {isGoogleDriveConnected ? <Cloud size={18} /> : <CloudOff size={18} />}
              </div>
              <div className="text-left">
                <p className={cn("text-xs font-bold", isGoogleDriveConnected ? "text-white" : "text-zinc-500")}>
                  {isGoogleDriveConnected ? "Google Drive Active" : "Connect Cloud"}
                </p>
                <p className="text-[9px] font-mono opacity-40 mt-0.5 uppercase tracking-wider">
                  {isGoogleDriveConnected ? "Auto-syncing data" : "Backups disabled"}
                </p>
              </div>
            </button>
          </div>

          {/* Member List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">Recent Members</h3>
              <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-md border border-white/10 bg-white/5 text-zinc-400">{members.length}</span>
            </div>
            <div className="space-y-2">
              {filteredMembers.slice(0, 12).map(member => (
                <button
                  key={member.id}
                  onClick={() => setSelectedMember(member)}
                  className={cn(
                    "w-full flex items-center gap-3 p-2.5 rounded-xl border transition-all group",
                    selectedMember?.id === member.id 
                      ? "bg-white/[0.05] border-white/20 shadow-xl" 
                      : "bg-transparent border-transparent hover:bg-white/[0.02] hover:border-white/5"
                  )}
                >
                  <div className="w-10 h-10 rounded-lg bg-zinc-900 overflow-hidden shrink-0 border border-white/5">
                    {member.photoUrl ? (
                      <img src={member.photoUrl} alt={member.fullName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-700">
                        <Users size={16} />
                      </div>
                    )}
                  </div>
                  <div className="text-left overflow-hidden">
                    <p className={cn(
                      "text-xs font-bold truncate transition-colors",
                      selectedMember?.id === member.id ? "text-white" : "text-zinc-400 group-hover:text-zinc-200"
                    )}>{member.fullName}</p>
                    <p className="text-[9px] text-zinc-600 font-mono truncate uppercase tracking-tight mt-0.5">{member.occupation || 'Member'}</p>
                  </div>
                  <ChevronRight size={12} className={cn(
                    "ml-auto transition-all",
                    selectedMember?.id === member.id ? "text-white translate-x-0" : "text-zinc-800 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0"
                  )} />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* User Section */}
        <div className="p-6 border-t border-white/5 bg-white/[0.01]">
          <Auth primaryColor={siteSettings.primaryColor} />
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className={cn(
        "flex-1 relative flex flex-col transition-colors duration-500",
        siteSettings.theme === 'light' ? "bg-zinc-50" : "bg-[#050505]"
      )}>
        {/* Header */}
        <header className={cn(
          "h-20 px-8 flex items-center justify-between border-b backdrop-blur-xl relative z-20 transition-all",
          siteSettings.theme === 'light' ? "bg-white/80 border-zinc-200" : "bg-black/20 border-white/5"
        )}>
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className={cn(
                "p-2.5 rounded-xl border transition-all hover:bg-white/5",
                siteSettings.theme === 'light' ? "bg-zinc-100 border-zinc-200 text-zinc-600" : "bg-white/[0.02] border-white/10 text-zinc-400"
              )}
            >
              {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="flex items-center gap-3">
              <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: siteSettings.primaryColor }} />
              <h2 className="text-sm font-black uppercase tracking-[0.2em] text-zinc-400">{siteSettings.headerTitle}</h2>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {(user || siteSettings.publicModeEnabled) && (
              <button
                onClick={handleAddMember}
                className="flex items-center gap-2 px-6 py-2.5 text-white text-xs font-black uppercase tracking-widest rounded-xl shadow-2xl transition-all transform hover:-translate-y-0.5 active:translate-y-0"
                style={{ backgroundColor: siteSettings.primaryColor, boxShadow: `0 10px 30px -5px ${siteSettings.primaryColor}4d` }}
              >
                <Plus size={16} />
                Add Member
              </button>
            )}
            
            <div className="flex items-center gap-1 p-1 bg-white/[0.03] rounded-xl border border-white/5">
              {user && (
                <button 
                  onClick={() => setIsAdminPanelOpen(true)}
                  className="p-2.5 rounded-lg text-zinc-500 hover:text-white hover:bg-white/5 transition-all"
                  title="Admin Panel"
                >
                  <Settings size={18} />
                </button>
              )}
              <button className="p-2.5 rounded-lg text-zinc-500 hover:text-white hover:bg-white/5 transition-all">
                <HelpCircle size={18} />
              </button>
            </div>
          </div>
        </header>

        {/* Tree Canvas */}
        <div className="flex-1 relative flex flex-col">
          <div className="flex-1 relative">
          {loading ? (
            <div className={cn(
              "absolute inset-0 flex items-center justify-center z-10",
              siteSettings.theme === 'light' ? "bg-zinc-50" : "bg-zinc-950"
            )}>
              <div className="flex flex-col items-center gap-4">
                <div className={cn(
                  "w-16 h-16 border-4 rounded-full animate-spin",
                  siteSettings.theme === 'light' ? "border-zinc-200" : "border-zinc-800"
                )} style={{ borderTopColor: siteSettings.primaryColor }} />
                <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest animate-pulse">Growing your tree...</p>
              </div>
            </div>
          ) : members.length === 0 ? (
            <div className="absolute inset-0 flex items-center justify-center p-8">
              <div className="max-w-md text-center space-y-8">
                <div className="w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto border shadow-[0_0_40px_rgba(16,185,129,0.1)]" style={{ backgroundColor: `${siteSettings.primaryColor}1a`, borderColor: `${siteSettings.primaryColor}33` }}>
                  <TreePine size={48} style={{ color: siteSettings.primaryColor }} />
                </div>
                <div className="space-y-3">
                  <h2 className={cn(
                    "text-3xl font-black tracking-tight",
                    siteSettings.theme === 'light' ? "text-zinc-900" : "text-white"
                  )}>Start Your Legacy</h2>
                  <p className="text-zinc-500 font-medium leading-relaxed">
                    Your family tree is currently empty. Begin by adding the first member of your ancestry.
                  </p>
                </div>
                {user ? (
                  <button
                    onClick={handleAddMember}
                    className="px-8 py-4 text-white font-bold rounded-2xl shadow-xl transition-all transform hover:-translate-y-1"
                    style={{ backgroundColor: siteSettings.primaryColor, boxShadow: `0 20px 25px -5px ${siteSettings.primaryColor}33` }}
                  >
                    Create First Member
                  </button>
                ) : (
                  <div className={cn(
                    "p-6 rounded-3xl border",
                    siteSettings.theme === 'light' ? "bg-zinc-100 border-zinc-200" : "bg-zinc-900/50 border-white/5"
                  )}>
                    <p className="text-sm text-zinc-400 font-medium mb-4">Login to start building your tree</p>
                    <Auth primaryColor={siteSettings.primaryColor} />
                  </div>
                )}
              </div>
            </div>
          ) : (
            <FamilyTree 
              members={visibleMembers} 
              onMemberClick={setSelectedMember}
              selectedMemberId={selectedMember?.id}
              primaryColor={siteSettings.primaryColor}
              settings={siteSettings}
            />
          )}
          </div>
        </div>

        {/* Profile Sidebar */}
        <AnimatePresence>
          {selectedMember && (
            <MemberProfile
              member={selectedMember}
              members={members}
              onClose={() => setSelectedMember(null)}
              onEdit={handleEditMember}
              onDelete={() => setSelectedMember(null)}
              primaryColor={siteSettings.primaryColor}
            />
          )}
        </AnimatePresence>

        {/* Member Form Modal */}
        {isFormOpen && (
          <MemberForm
            members={members}
            editingMember={editingMember}
            onClose={() => setIsFormOpen(false)}
            onSuccess={() => {
              setIsFormOpen(false);
              setEditingMember(null);
            }}
            primaryColor={siteSettings.primaryColor}
            publicModeEnabled={siteSettings.publicModeEnabled}
          />
        )}

        {/* Admin Panel Modal */}
        {isAdminPanelOpen && user && (
          <AdminPanel
            userId={user.uid}
            members={members}
            onClose={() => setIsAdminPanelOpen(false)}
          />
        )}

        {/* Footer */}
        <footer className={cn(
          "h-12 px-8 flex flex-col items-center justify-center border-t backdrop-blur-md relative z-20 transition-all",
          siteSettings.theme === 'light' ? "bg-white/80 border-zinc-200" : "bg-zinc-950/50 border-white/5",
          siteSettings.adsEnabled && siteSettings.adPosition === 'footer' && "h-auto py-4"
        )}>
          {siteSettings.adsEnabled && siteSettings.adPosition === 'footer' && (
            <AdComponent settings={siteSettings} className="mb-4 w-full max-w-4xl" />
          )}
          <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">
            {siteSettings.footerText}
          </p>
        </footer>
      </main>
    </div>
  );
}
