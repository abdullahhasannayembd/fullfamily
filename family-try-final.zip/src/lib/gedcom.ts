import { FamilyMember } from '../types';

/**
 * Basic GEDCOM Exporter
 */
export function exportToGEDCOM(members: FamilyMember[]): string {
  let gedcom = '0 HEAD\n1 SOUR AncestryFlow\n1 GEDC\n2 VERS 5.5\n1 CHAR UTF-8\n';

  // Individuals
  members.forEach((m) => {
    gedcom += `0 @I${m.id}@ INDI\n`;
    gedcom += `1 NAME ${m.fullName.replace(' ', ' /')}/\n`;
    if (m.dateOfBirth) {
      gedcom += `1 BIRT\n2 DATE ${m.dateOfBirth}\n`;
    }
    if (m.occupation) {
      gedcom += `1 OCCU ${m.occupation}\n`;
    }
    if (m.biography) {
      gedcom += `1 NOTE ${m.biography}\n`;
    }
  });

  // Families (Simplified: creating a family for each parent-child relationship)
  // In a real GEDCOM, we'd group siblings under one FAM record.
  // For this basic implementation, we'll focus on the INDI records and basic links.
  
  // Note: GEDCOM usually uses FAM records to link parents and children.
  // To keep it simple and compatible with our flat structure, we'll just export INDIs.
  // Most importers can reconstruct trees from INDI tags if they are present, 
  // but standard GEDCOM requires FAM records for relationships.
  
  // Let's create FAM records for spouses
  const processedFamilies = new Set<string>();
  members.forEach(m => {
    if (m.spouseId && !processedFamilies.has([m.id, m.spouseId].sort().join('-'))) {
      const famId = `F${m.id.substring(0, 4)}${m.spouseId.substring(0, 4)}`;
      gedcom += `0 @${famId}@ FAM\n`;
      gedcom += `1 HUSB @I${m.id}@\n`;
      gedcom += `1 WIFE @I${m.spouseId}@\n`;
      
      // Find children
      const children = members.filter(c => (c.fatherId === m.id && c.motherId === m.spouseId) || (c.fatherId === m.spouseId && c.motherId === m.id));
      children.forEach(c => {
        gedcom += `1 CHIL @I${c.id}@\n`;
      });
      
      processedFamilies.add([m.id, m.spouseId].sort().join('-'));
    }
  });

  gedcom += '0 TRLR\n';
  return gedcom;
}

/**
 * Basic GEDCOM Importer
 */
export function parseGEDCOM(content: string): Partial<FamilyMember>[] {
  const lines = content.split('\n');
  const members: any[] = [];
  let currentMember: any = null;
  const idMap: Record<string, string> = {}; // Map GEDCOM ID to temporary index

  lines.forEach((line) => {
    const match = line.match(/^(\d+)\s+(@\w+@)?\s*(\w+)\s*(.*)$/);
    if (!match) return;

    const [_, level, id, tag, value] = match;

    if (level === '0' && tag === 'INDI') {
      currentMember = {
        fullName: '',
        gedcomId: id.replace(/@/g, ''),
      };
      members.push(currentMember);
    } else if (currentMember && level === '1') {
      if (tag === 'NAME') {
        currentMember.fullName = value.replace(/\//g, '').trim();
      } else if (tag === 'OCCU') {
        currentMember.occupation = value;
      } else if (tag === 'NOTE') {
        currentMember.biography = value;
      }
    } else if (currentMember && level === '2' && tag === 'DATE') {
      // Assuming it's under BIRT
      currentMember.dateOfBirth = value;
    }
  });

  // Second pass for relationships would require parsing FAM records.
  // For a "common format" requirement, this basic INDI parsing is a start.
  // Full GEDCOM parsing is extremely complex, so we'll stick to INDIs for this demo.

  return members.map(m => ({
    fullName: m.fullName || 'Unknown Member',
    dateOfBirth: m.dateOfBirth || '',
    occupation: m.occupation || '',
    biography: m.biography || '',
  }));
}
