export interface FamilyMember {
  id: string;
  fullName: string;
  fatherId?: string;
  motherId?: string;
  spouseId?: string;
  dateOfBirth?: string;
  dateOfDeath?: string;
  occupation?: string;
  biography?: string;
  photoUrl?: string;
  location?: string; // Added for Family Origin Map
  generation?: number; // Added for filtering
  branch?: string; // Added for filtering
  createdBy: string;
  createdAt: number;
  updatedAt?: number;
  status?: 'approved' | 'pending'; // Added for public mode approval
}

export interface FamilyEvent {
  id: string;
  title: string;
  date: string;
  description: string;
  type: 'birth' | 'marriage' | 'death' | 'other';
  memberIds: string[];
}

export interface SiteSettings {
  id: string;
  headerTitle: string;
  familyName: string;
  logoUrl?: string;
  footerText: string;
  primaryColor: string;
  accentColor: string;
  theme: 'dark' | 'light';
  updatedAt: number;
  updatedBy: string;
  // Ad Configuration
  adsEnabled: boolean;
  adsterraCode?: string;
  customAdImage?: string;
  customAdLink?: string;
  adPosition: 'sidebar' | 'footer' | 'top' | 'floating';
  // Tree Control
  autoGenerateTree: boolean;
  showGenerations: boolean;
  defaultExpandedGenerations: number;
  // Public Mode
  publicModeEnabled: boolean;
}

export interface AdminUser {
  uid: string;
  email: string;
  role: 'admin' | 'editor' | 'viewer';
  lastLogin: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  createdAt: number;
  lastLogin: number;
}
