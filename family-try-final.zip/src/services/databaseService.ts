import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  deleteDoc,
  updateDoc,
  addDoc,
  writeBatch,
  Timestamp
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage, auth } from '../firebase';
import { FamilyMember, SiteSettings, AdminUser, FamilyEvent, UserProfile } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firebase-errors';

export const databaseService = {
  // --- User Profiles ---
  async getUserProfile(uid: string): Promise<UserProfile | null> {
    const path = `users/${uid}`;
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data() as UserProfile;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  },

  async updateUserProfile(uid: string, profile: Partial<UserProfile>): Promise<void> {
    const path = `users/${uid}`;
    try {
      const docRef = doc(db, 'users', uid);
      const existing = await this.getUserProfile(uid);
      if (!existing) {
        await setDoc(docRef, {
          ...profile,
          uid,
          createdAt: Date.now(),
          lastLogin: Date.now()
        });
      } else {
        await updateDoc(docRef, {
          ...profile,
          lastLogin: Date.now()
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // --- Site Settings ---
  async getSettings(): Promise<SiteSettings | null> {
    const path = 'settings/global';
    try {
      const docRef = doc(db, 'settings', 'global');
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data() as SiteSettings;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  },

  async updateSettings(settings: Partial<SiteSettings>, userId: string): Promise<void> {
    const path = 'settings/global';
    try {
      const docRef = doc(db, 'settings', 'global');
      await setDoc(docRef, {
        ...settings,
        updatedAt: Date.now(),
        updatedBy: userId
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // --- Family Members ---
  async addMember(member: Omit<FamilyMember, 'id'>): Promise<string> {
    const path = 'members';
    try {
      const docRef = await addDoc(collection(db, 'members'), {
        ...member,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
      return '';
    }
  },

  async updateMember(id: string, member: Partial<FamilyMember>): Promise<void> {
    const path = `members/${id}`;
    try {
      const docRef = doc(db, 'members', id);
      await updateDoc(docRef, {
        ...member,
        updatedAt: Date.now()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async deleteMember(id: string): Promise<void> {
    const path = `members/${id}`;
    try {
      // Optionally delete photo from storage if exists
      const memberSnap = await getDoc(doc(db, 'members', id));
      if (memberSnap.exists()) {
        const data = memberSnap.data() as FamilyMember;
        if (data.photoUrl && data.photoUrl.includes('firebasestorage')) {
          try {
            const photoRef = ref(storage, data.photoUrl);
            await deleteObject(photoRef);
          } catch (e) {
            console.error("Failed to delete photo from storage", e);
          }
        }
      }
      await deleteDoc(doc(db, 'members', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // --- Photos ---
  async uploadPhoto(file: File, path: string): Promise<string> {
    const storageRef = ref(storage, `${path}/${Date.now()}_${file.name}`);
    await uploadBytes(storageRef, file);
    return await getDownloadURL(storageRef);
  },

  // --- Admin Users ---
  async getAdminUser(uid: string): Promise<AdminUser | null> {
    const path = `admins/${uid}`;
    try {
      const docRef = doc(db, 'admins', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { uid: docSnap.id, ...docSnap.data() } as AdminUser;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  },

  async updateAdminUser(uid: string, data: Partial<AdminUser>): Promise<void> {
    const path = `admins/${uid}`;
    try {
      const docRef = doc(db, 'admins', uid);
      await setDoc(docRef, {
        ...data,
        lastLogin: Date.now()
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // --- Initialization ---
  async initializeDatabase(userId: string): Promise<void> {
    try {
      const settings = await this.getSettings();
      if (!settings) {
        const defaultSettings: SiteSettings = {
          id: 'global',
          headerTitle: 'Main Family Tree',
          familyName: 'The Family',
          footerText: '© 2024 Family Tree Explorer. All rights reserved.',
          primaryColor: '#10b981',
          accentColor: '#34d399',
          theme: 'dark',
          adsEnabled: false,
          adPosition: 'sidebar',
          autoGenerateTree: true,
          showGenerations: true,
          defaultExpandedGenerations: 3,
          publicModeEnabled: false,
          updatedAt: Date.now(),
          updatedBy: userId
        };
        await setDoc(doc(db, 'settings', 'global'), defaultSettings);
      }

      // Ensure current user is an admin if they are the first one
      const adminsSnap = await getDocs(collection(db, 'admins'));
      if (adminsSnap.empty && auth.currentUser) {
        await this.updateAdminUser(auth.currentUser.uid, {
          email: auth.currentUser.email || '',
          role: 'admin',
          lastLogin: Date.now()
        });
      }

      // Update general user profile
      if (auth.currentUser) {
        await this.updateUserProfile(auth.currentUser.uid, {
          displayName: auth.currentUser.displayName || 'Anonymous',
          email: auth.currentUser.email || '',
          photoURL: auth.currentUser.photoURL || ''
        });
      }
    } catch (error) {
      console.error("Initialization error:", error);
    }
  }
};
