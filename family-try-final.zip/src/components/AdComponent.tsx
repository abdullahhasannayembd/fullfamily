import React, { useEffect, useRef } from 'react';
import { SiteSettings } from '../types';
import { cn } from '../lib/utils';
import { ExternalLink, X } from 'lucide-react';

interface Props {
  settings: SiteSettings;
  className?: string;
}

export const AdComponent: React.FC<Props> = ({ settings, className }) => {
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (settings.adsEnabled && settings.adsterraCode && adRef.current) {
      // Clear previous content
      adRef.current.innerHTML = '';
      
      // Create a script element
      const script = document.createElement('script');
      script.type = 'text/javascript';
      
      // Adsterra scripts often look like:
      // atOptions = { 'key' : '...', 'format' : 'iframe', ... };
      // document.write('<script type="text/javascript" src="..."></script>');
      
      // Since we can't use document.write easily in React, we might need a workaround 
      // if the user provides the full script tag. 
      // For now, we'll try to inject the code provided.
      
      try {
        // If it's just a URL or a specific script tag, we handle it.
        // Most users will paste the whole <script> block.
        const container = document.createElement('div');
        container.innerHTML = settings.adsterraCode;
        
        const scripts = container.getElementsByTagName('script');
        for (let i = 0; i < scripts.length; i++) {
          const s = document.createElement('script');
          if (scripts[i].src) {
            s.src = scripts[i].src;
          } else {
            s.textContent = scripts[i].textContent;
          }
          adRef.current.appendChild(s);
        }
        
        // Append non-script elements too
        Array.from(container.childNodes).forEach(node => {
          if (node.nodeName !== 'SCRIPT') {
            adRef.current?.appendChild(node.cloneNode(true));
          }
        });
      } catch (e) {
        console.error("Failed to inject Adsterra code:", e);
      }
    }
  }, [settings.adsEnabled, settings.adsterraCode]);

  if (!settings.adsEnabled) return null;

  return (
    <div className={cn("relative overflow-hidden rounded-xl", className)}>
      {/* Custom Ad */}
      {settings.customAdImage && (
        <a 
          href={settings.customAdLink || '#'} 
          target="_blank" 
          rel="noopener noreferrer"
          className="block group relative"
        >
          <img 
            src={settings.customAdImage} 
            alt="Advertisement" 
            className="w-full h-auto object-cover rounded-xl transition-transform group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <ExternalLink className="text-white" size={24} />
          </div>
          <div className="absolute top-2 right-2 px-2 py-0.5 bg-black/60 backdrop-blur-md rounded text-[8px] font-bold text-white uppercase tracking-widest">
            Sponsored
          </div>
        </a>
      )}

      {/* Adsterra Container */}
      {settings.adsterraCode && (
        <div ref={adRef} className="adsterra-container flex justify-center min-h-[50px]" />
      )}
    </div>
  );
};
