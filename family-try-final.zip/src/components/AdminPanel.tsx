import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { doc, setDoc, collection, onSnapshot, query, orderBy, deleteDoc, writeBatch, updateDoc } from 'firebase/firestore';
import { SiteSettings, FamilyMember, AdminUser, FamilyEvent } from '../types';
import { 
  X, Save, Loader2, Layout, Palette, Type, BrainCircuit, Users, 
  History, Sparkles, ChevronRight, BarChart3, UserCog, Database, 
  Map, Calendar, Shield, Image as ImageIcon, Plus, Trash2, Edit2,
  Download, Upload, FileText, Clock, Settings, RefreshCw, Megaphone,
  Link as LinkIcon, CheckCircle2, ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type as SchemaType } from "@google/genai";
import { cn } from '../lib/utils';
import { MemberForm } from './MemberForm';

interface Props {
  onClose: () => void;
  userId: string;
  members: FamilyMember[];
}

interface RelationshipSuggestion {
  member1Id: string;
  member1Name: string;
  member2Id: string;
  member2Name: string;
  suggestedRelationship: string;
  reason: string;
}

type AdminTab = 'dashboard' | 'members' | 'tree' | 'data' | 'users' | 'history' | 'settings' | 'ai' | 'security' | 'map' | 'media' | 'ads' | 'approvals';

export const AdminPanel: React.FC<Props> = ({ onClose, userId, members }) => {
  const [settings, setSettings] = useState<SiteSettings>({
    id: 'global',
    headerTitle: 'Main Family Tree',
    familyName: 'The Family',
    footerText: '© 2024 Family Tree Explorer. All rights reserved.',
    primaryColor: '#10b981',
    accentColor: '#34d399',
    theme: 'dark',
    adsEnabled: false,
    adPosition: 'sidebar',
    autoGenerateTree: true,
    showGenerations: true,
    defaultExpandedGenerations: 3,
    publicModeEnabled: false,
    updatedAt: Date.now(),
    updatedBy: userId
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzingGenealogy, setAnalyzingGenealogy] = useState(false);
  const [suggestions, setSuggestions] = useState<RelationshipSuggestion[]>([]);
  const [genealogyReport, setGenealogyReport] = useState<string>('');
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [isMemberFormOpen, setIsMemberFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([]);
  const [familyEvents, setFamilyEvents] = useState<FamilyEvent[]>([]);

  useEffect(() => {
    const settingsUnsubscribe = onSnapshot(doc(db, 'settings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setSettings(snapshot.data() as SiteSettings);
      }
      setLoading(false);
    }, (error) => {
      console.error("Error fetching settings:", error);
      setLoading(false);
    });

    // Listen for admin users
    const usersUnsubscribe = onSnapshot(collection(db, 'admins'), (snapshot) => {
      setAdminUsers(snapshot.docs.map(d => ({ uid: d.id, ...d.data() } as AdminUser)));
    });

    // Listen for family events
    const eventsUnsubscribe = onSnapshot(query(collection(db, 'events'), orderBy('date', 'desc')), (snapshot) => {
      setFamilyEvents(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as FamilyEvent)));
    });

    return () => {
      settingsUnsubscribe();
      usersUnsubscribe();
      eventsUnsubscribe();
    };
  }, []);

  const stats = {
    totalMembers: members.length,
    generations: Array.from(new Set(members.map(m => m.generation || 0))).length,
    recentMembers: members.filter(m => m.createdAt > Date.now() - 7 * 24 * 60 * 60 * 1000).length,
    pendingApprovals: members.filter(m => m.status === 'pending').length,
    birthdaysToday: members.filter(m => {
      if (!m.dateOfBirth) return false;
      const dob = new Date(m.dateOfBirth);
      const today = new Date();
      return dob.getMonth() === today.getMonth() && dob.getDate() === today.getDate();
    }).length
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSaving(true);
    try {
      const updatedSettings = {
        ...settings,
        updatedAt: Date.now(),
        updatedBy: userId
      };
      await setDoc(doc(db, 'settings', 'global'), updatedSettings);
      alert("Settings saved successfully!");
    } catch (error) {
      console.error("Error saving settings:", error);
      alert("Failed to save settings.");
    } finally {
      setSaving(false);
    }
  };

  const analyzeRelationships = async () => {
    if (members.length < 2) {
      alert("Need at least 2 members to analyze relationships.");
      return;
    }
    setAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const memberDataForAI = members.map(m => ({
        id: m.id,
        name: m.fullName,
        fatherId: m.fatherId,
        motherId: m.motherId,
        spouseId: m.spouseId,
        dob: m.dateOfBirth,
        bio: m.biography
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analyze this family member data and suggest potential missing relationships (parents, children, siblings, or spouses) that are not currently explicitly linked but seem likely based on names, dates, or biographies. Return a JSON array of suggestions.
        
        Member Data: ${JSON.stringify(memberDataForAI)}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: SchemaType.ARRAY,
            items: {
              type: SchemaType.OBJECT,
              properties: {
                member1Id: { type: SchemaType.STRING },
                member1Name: { type: SchemaType.STRING },
                member2Id: { type: SchemaType.STRING },
                member2Name: { type: SchemaType.STRING },
                suggestedRelationship: { type: SchemaType.STRING },
                reason: { type: SchemaType.STRING }
              },
              required: ["member1Id", "member1Name", "member2Id", "member2Name", "suggestedRelationship", "reason"]
            }
          }
        }
      });

      const result = JSON.parse(response.text);
      setSuggestions(result);
    } catch (error) {
      console.error("AI Analysis failed:", error);
      alert("AI Analysis failed.");
    } finally {
      setAnalyzing(false);
    }
  };

  const analyzeGenealogy = async () => {
    if (members.length < 1) {
      alert("Need members to analyze genealogy.");
      return;
    }
    setAnalyzingGenealogy(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const memberDataForAI = members.map(m => ({
        name: m.fullName,
        dob: m.dateOfBirth,
        occupation: m.occupation,
        bio: m.biography
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analyze this family's genealogy. Provide a summary of the family's history, common occupations, longevity, and any interesting patterns you find. Format as a professional report.
        
        Member Data: ${JSON.stringify(memberDataForAI)}`,
      });

      setGenealogyReport(response.text);
    } catch (error) {
      console.error("Genealogy Analysis failed:", error);
      alert("Genealogy Analysis failed.");
    } finally {
      setAnalyzingGenealogy(false);
    }
  };

  const [memberFilter, setMemberFilter] = useState<'all' | 'pending' | 'approved'>('all');

  const filteredMembersList = members.filter(m => {
    if (memberFilter === 'all') return true;
    if (memberFilter === 'pending') return m.status === 'pending';
    if (memberFilter === 'approved') return m.status === 'approved' || !m.status;
    return true;
  });

  const handleApproveMember = async (memberId: string) => {
    try {
      await updateDoc(doc(db, 'members', memberId), {
        status: 'approved',
        updatedAt: Date.now()
      });
    } catch (err) {
      console.error("Error approving member:", err);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: settings.primaryColor }} />
      </div>
    );
  }

  const SidebarItem = ({ id, icon: Icon, label }: { id: AdminTab, icon: any, label: string }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all",
        activeTab === id 
          ? "bg-white/10 text-white" 
          : "text-zinc-500 hover:bg-white/5 hover:text-zinc-300"
      )}
      style={activeTab === id ? { color: settings.primaryColor } : {}}
    >
      <Icon size={18} />
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-[#050505] border border-white/5 rounded-[3rem] w-full max-w-6xl h-[85vh] overflow-hidden shadow-2xl flex"
      >
        {/* Admin Sidebar */}
        <div className="w-72 bg-white/[0.01] border-r border-white/5 flex flex-col p-8 space-y-10">
          <div className="flex items-center gap-4 px-2">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <Shield className="text-indigo-400" size={24} />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tighter leading-none font-serif italic">Admin Portal</h2>
              <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em] mt-1">Management Suite</p>
            </div>
          </div>

          <div className="flex-1 space-y-1 overflow-y-auto custom-scrollbar">
            <SidebarItem id="dashboard" icon={BarChart3} label="Dashboard" />
            <SidebarItem id="members" icon={Users} label="Members" />
            <SidebarItem id="tree" icon={Layout} label="Tree Control" />
            <SidebarItem id="data" icon={Database} label="Data & Backup" />
            <SidebarItem id="users" icon={UserCog} label="User Roles" />
            <SidebarItem id="history" icon={History} label="History & Timeline" />
            <SidebarItem id="settings" icon={Settings} label="Site Settings" />
            <SidebarItem id="ai" icon={BrainCircuit} label="AI Lab" />
            <SidebarItem id="map" icon={Map} label="Origin Map" />
            <SidebarItem id="media" icon={ImageIcon} label="Media Library" />
            <SidebarItem id="ads" icon={Megaphone} label="Ads Setup" />
            <SidebarItem id="security" icon={Shield} label="Security" />
          </div>

          <button 
            onClick={onClose}
            className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-xs font-black uppercase tracking-widest text-zinc-500 hover:bg-red-500/10 hover:text-red-400 transition-all border border-transparent hover:border-red-500/20"
          >
            <X size={18} />
            Exit Dashboard
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden bg-white/[0.01]">
          <header className="px-10 py-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
            <div>
              <h3 className="text-2xl font-black text-white tracking-tighter capitalize font-serif italic">{activeTab.replace('-', ' ')}</h3>
              <p className="text-[10px] text-zinc-500 font-black uppercase tracking-[0.2em] mt-1">Manage your family heritage platform</p>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-3 px-4 py-2 bg-white/[0.03] rounded-full border border-white/5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
                <span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">System Online</span>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
            <AnimatePresence mode="wait">
              {activeTab === 'dashboard' && (
                <motion.div 
                  key="dashboard"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-10"
                >
                  <div className="grid grid-cols-5 gap-6">
                    <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-4 group hover:bg-white/[0.04] transition-all">
                      <Users className="text-indigo-400" size={28} />
                      <div>
                        <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Total Members</p>
                        <h4 className="text-4xl font-black text-white tracking-tighter mt-1">{stats.totalMembers}</h4>
                      </div>
                    </div>
                    <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-4 group hover:bg-white/[0.04] transition-all">
                      <Layout className="text-emerald-400" size={28} />
                      <div>
                        <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Generations</p>
                        <h4 className="text-4xl font-black text-white tracking-tighter mt-1">{stats.generations}</h4>
                      </div>
                    </div>
                    <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-4 group hover:bg-white/[0.04] transition-all">
                      <Clock className="text-amber-400" size={28} />
                      <div>
                        <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Recent (7d)</p>
                        <h4 className="text-4xl font-black text-white tracking-tighter mt-1">{stats.recentMembers}</h4>
                      </div>
                    </div>
                    <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-4 cursor-pointer hover:bg-white/[0.06] transition-all" onClick={() => { setActiveTab('members'); setMemberFilter('pending'); }}>
                      <Shield className="text-amber-500" size={28} />
                      <div>
                        <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Pending</p>
                        <h4 className="text-4xl font-black text-white tracking-tighter mt-1">{stats.pendingApprovals}</h4>
                      </div>
                    </div>
                    <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-4 group hover:bg-white/[0.04] transition-all">
                      <Calendar className="text-rose-400" size={28} />
                      <div>
                        <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Birthdays</p>
                        <h4 className="text-4xl font-black text-white tracking-tighter mt-1">{stats.birthdaysToday}</h4>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-8">
                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Recently Added</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <div className="space-y-4">
                        {members.slice(0, 5).map(m => (
                          <div key={m.id} className="flex items-center gap-5 p-4 bg-white/[0.02] rounded-[1.5rem] border border-white/5 hover:bg-white/[0.04] transition-all group">
                            <div className="w-12 h-12 rounded-2xl bg-zinc-900 overflow-hidden border border-white/5">
                              {m.photoUrl ? <img src={m.photoUrl} className="w-full h-full object-cover" /> : <Users className="w-full h-full p-3 text-zinc-700" />}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-white">{m.fullName}</p>
                              <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest mt-0.5">{m.occupation || 'Member'}</p>
                            </div>
                            <span className="ml-auto text-[10px] text-zinc-700 font-mono font-bold uppercase">{new Date(m.createdAt).toLocaleDateString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 flex flex-col items-center justify-center text-center space-y-6">
                      <div className="w-20 h-20 rounded-[2rem] bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center shadow-[0_0_50px_rgba(99,102,241,0.1)]">
                        <Plus className="text-indigo-400" size={40} />
                      </div>
                      <div>
                        <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Expand the Heritage</h4>
                        <p className="text-sm text-zinc-500 mt-2">Add a new family member to the archive instantly</p>
                      </div>
                      <button 
                        onClick={() => {
                          setEditingMember(null);
                          setIsMemberFormOpen(true);
                        }}
                        className="px-10 py-4 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all transform hover:-translate-y-1"
                      >
                        Add Member
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'members' && (
                <motion.div key="members" className="space-y-8">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-3 p-1.5 bg-white/[0.03] rounded-2xl border border-white/5">
                      <button 
                        onClick={() => setMemberFilter('all')}
                        className={cn(
                          "px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                          memberFilter === 'all' ? "bg-white/10 text-white shadow-xl" : "text-zinc-500 hover:text-zinc-300"
                        )}
                      >
                        All
                      </button>
                      <button 
                        onClick={() => setMemberFilter('pending')}
                        className={cn(
                          "px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3",
                          memberFilter === 'pending' ? "bg-amber-500/10 text-amber-500 shadow-xl" : "text-zinc-500 hover:text-zinc-300"
                        )}
                      >
                        Pending
                        {members.filter(m => m.status === 'pending').length > 0 && (
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                        )}
                      </button>
                      <button 
                        onClick={() => setMemberFilter('approved')}
                        className={cn(
                          "px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                          memberFilter === 'approved' ? "bg-emerald-500/10 text-emerald-500 shadow-xl" : "text-zinc-500 hover:text-zinc-300"
                        )}
                      >
                        Approved
                      </button>
                    </div>
                    <button 
                      onClick={() => {
                        setEditingMember(null);
                        setIsMemberFormOpen(true);
                      }}
                      className="flex items-center gap-3 px-8 py-3 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl transition-all transform hover:-translate-y-0.5"
                    >
                      <Plus size={16} />
                      Add New
                    </button>
                  </div>
                  <div className="bg-white/[0.01] rounded-[2.5rem] border border-white/5 overflow-hidden">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-white/5 bg-white/[0.01]">
                          <th className="px-8 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Member</th>
                          <th className="px-8 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Status</th>
                          <th className="px-8 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Occupation</th>
                          <th className="px-8 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredMembersList.map(m => (
                          <tr key={m.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
                            <td className="px-8 py-5">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl bg-zinc-900 overflow-hidden border border-white/5">
                                  {m.photoUrl ? <img src={m.photoUrl} className="w-full h-full object-cover" /> : <Users className="p-2.5 text-zinc-700" />}
                                </div>
                                <span className="text-sm font-bold text-white">{m.fullName}</span>
                              </div>
                            </td>
                            <td className="px-8 py-5">
                              {m.status === 'pending' ? (
                                <span className="px-3 py-1 bg-amber-500/10 text-amber-500 text-[9px] font-black uppercase tracking-widest rounded-full border border-amber-500/20">Pending</span>
                              ) : (
                                <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 text-[9px] font-black uppercase tracking-widest rounded-full border border-emerald-500/20">Approved</span>
                              )}
                            </td>
                            <td className="px-8 py-5 text-xs text-zinc-500 font-mono uppercase tracking-tight">{m.occupation || '-'}</td>
                            <td className="px-8 py-5 text-right">
                              <div className="flex items-center justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-0 translate-x-4">
                                {m.status === 'pending' && (
                                  <button 
                                    onClick={() => handleApproveMember(m.id)}
                                    className="p-2.5 hover:bg-emerald-500/10 rounded-xl text-emerald-500 border border-transparent hover:border-emerald-500/20"
                                    title="Approve Member"
                                  >
                                    <Sparkles size={16} />
                                  </button>
                                )}
                                <button 
                                  onClick={() => {
                                    setEditingMember(m);
                                    setIsMemberFormOpen(true);
                                  }}
                                  className="p-2.5 hover:bg-white/5 rounded-xl text-zinc-500 hover:text-white border border-transparent hover:border-white/10"
                                >
                                  <Edit2 size={16} />
                                </button>
                                <button 
                                  onClick={async () => {
                                    if (confirm(`Are you sure you want to delete ${m.fullName}?`)) {
                                      try {
                                        await deleteDoc(doc(db, 'members', m.id));
                                      } catch (err) {
                                        console.error("Error deleting member:", err);
                                      }
                                    }
                                  }}
                                  className="p-2.5 hover:bg-red-500/10 rounded-xl text-zinc-500 hover:text-red-400 border border-transparent hover:border-red-500/20"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div key="settings" className="space-y-10">
                  <div className="max-w-3xl space-y-10">
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">General Configuration</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Website Title</label>
                          <input 
                            type="text" 
                            value={settings.headerTitle}
                            onChange={(e) => setSettings({...settings, headerTitle: e.target.value})}
                            className="w-full px-6 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all"
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Family Name</label>
                          <input 
                            type="text" 
                            value={settings.familyName}
                            onChange={(e) => setSettings({...settings, familyName: e.target.value})}
                            className="w-full px-6 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Appearance & Theme</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Primary Color</label>
                          <div className="flex gap-4">
                            <input
                              type="color"
                              value={settings.primaryColor}
                              onChange={e => setSettings({ ...settings, primaryColor: e.target.value })}
                              className="w-14 h-14 rounded-2xl bg-transparent border-none cursor-pointer"
                            />
                            <input
                              type="text"
                              value={settings.primaryColor}
                              onChange={e => setSettings({ ...settings, primaryColor: e.target.value })}
                              className="flex-1 bg-white/[0.02] border border-white/5 rounded-2xl px-6 py-4 text-white font-mono text-sm focus:outline-none focus:border-indigo-500/50 transition-all"
                            />
                          </div>
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">System Theme</label>
                          <div className="grid grid-cols-2 gap-3">
                            {['dark', 'light'].map(t => (
                              <button 
                                key={t}
                                onClick={() => setSettings({...settings, theme: t as any})}
                                className={cn(
                                  "px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all",
                                  settings.theme === t 
                                    ? "bg-indigo-600/10 border-indigo-500/50 text-indigo-400" 
                                    : "bg-white/[0.02] border-white/5 text-zinc-600 hover:text-zinc-400"
                                )}
                              >
                                {t}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-8 bg-indigo-600/5 border border-indigo-500/10 rounded-[2.5rem] flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-white">Public Submission Mode</p>
                        <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Allow visitors to suggest new members</p>
                      </div>
                      <div 
                        onClick={() => setSettings({...settings, publicModeEnabled: !settings.publicModeEnabled})}
                        className={cn(
                          "w-14 h-7 rounded-full relative cursor-pointer transition-all",
                          settings.publicModeEnabled ? "bg-indigo-600" : "bg-zinc-800"
                        )}
                      >
                        <div className={cn(
                          "absolute top-1 w-5 h-5 bg-white rounded-full transition-all shadow-lg",
                          settings.publicModeEnabled ? "right-1" : "left-1"
                        )} />
                      </div>
                    </div>

                    <button 
                      onClick={() => handleSave()}
                      disabled={saving}
                      className="px-12 py-5 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all transform hover:-translate-y-1 disabled:opacity-50 flex items-center gap-3"
                    >
                      {saving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                      Save Site Configuration
                    </button>
                  </div>
                </motion.div>
              )}

              {activeTab === 'ai' && (
                <motion.div key="ai" className="space-y-10">
                  <div className="grid grid-cols-2 gap-8">
                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">AI Relationship Lab</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <p className="text-sm text-zinc-500 leading-relaxed">Our neural engine analyzes your tree to detect missing connections, potential duplicates, and historical inconsistencies.</p>
                      <button 
                        onClick={analyzeRelationships}
                        disabled={analyzing}
                        className="w-full flex items-center justify-center gap-3 py-5 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all disabled:opacity-50"
                      >
                        {analyzing ? <Loader2 className="animate-spin" size={18} /> : <BrainCircuit size={18} />}
                        {analyzing ? 'Analyzing Neural Patterns...' : 'Start Deep Analysis'}
                      </button>
                    </div>

                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Narrative Generator</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <p className="text-sm text-zinc-500 leading-relaxed">Transform your raw data into a compelling family narrative. AI will synthesize biographies into a cohesive heritage report.</p>
                      <button 
                        onClick={analyzeGenealogy}
                        disabled={analyzingGenealogy}
                        className="w-full flex items-center justify-center gap-3 py-5 bg-white/[0.03] border border-white/5 text-zinc-400 text-xs font-black uppercase tracking-widest rounded-2xl hover:bg-white/5 hover:text-white transition-all disabled:opacity-50"
                      >
                        {analyzingGenealogy ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                        Generate Heritage Report
                      </button>
                    </div>
                  </div>

                  {suggestions.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-10 bg-indigo-600/5 border border-indigo-500/10 rounded-[3rem] space-y-8"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">Neural Insights Detected</h4>
                        <div className="w-12 h-[1px] bg-indigo-500/20" />
                      </div>
                      <div className="grid grid-cols-2 gap-6">
                        {suggestions.map((s, i) => (
                          <div key={i} className="p-6 bg-white/[0.02] border border-white/5 rounded-3xl flex items-start gap-5 group hover:bg-white/[0.04] transition-all">
                            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                              <LinkIcon size={18} />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-3">
                                <span className="text-sm font-bold text-white">{s.member1Name}</span>
                                <ChevronRight size={14} className="text-zinc-600" />
                                <span className="text-sm font-bold text-white">{s.member2Name}</span>
                              </div>
                              <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest mt-1">Suggested: {s.suggestedRelationship}</p>
                              <p className="text-xs text-zinc-600 mt-3 leading-relaxed italic">"{s.reason}"</p>
                            </div>
                            <button className="px-4 py-2 bg-white/5 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest text-white rounded-xl transition-all opacity-0 group-hover:opacity-100">
                              Link Now
                            </button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {genealogyReport && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-6"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Genealogy Report</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[3rem] text-zinc-300 text-sm leading-relaxed whitespace-pre-wrap font-serif italic">
                        {genealogyReport}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {activeTab === 'tree' && (
                <motion.div key="tree" className="space-y-10">
                  <div className="grid grid-cols-2 gap-8">
                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-5">
                          <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                            <Layout className="text-emerald-400" size={28} />
                          </div>
                          <div>
                            <h4 className="text-xl font-black text-white tracking-tighter font-serif italic">Visualization Engine</h4>
                            <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em] mt-1">Configure tree rendering logic</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => handleSave()}
                          disabled={saving}
                          className="flex items-center gap-3 px-8 py-3 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl transition-all transform hover:-translate-y-1 disabled:opacity-50"
                        >
                          {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                          Save Engine Config
                        </button>
                      </div>

                      <div className="space-y-6">
                        <div className="flex items-center justify-between p-6 bg-white/[0.02] rounded-3xl border border-white/5 group hover:bg-white/[0.04] transition-all">
                          <div className="space-y-1">
                            <p className="text-sm font-bold text-white">Auto-Generate Tree</p>
                            <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Dynamic layout calculation</p>
                          </div>
                          <div 
                            onClick={() => setSettings({ ...settings, autoGenerateTree: !settings.autoGenerateTree })}
                            className={cn(
                              "w-12 h-6 rounded-full relative cursor-pointer transition-all",
                              settings.autoGenerateTree ? "bg-emerald-600" : "bg-zinc-800"
                            )}
                          >
                            <div className={cn(
                              "absolute top-1 w-4 h-4 bg-white rounded-full transition-all shadow-lg",
                              settings.autoGenerateTree ? "right-1" : "left-1"
                            )} />
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-6 bg-white/[0.02] rounded-3xl border border-white/5 group hover:bg-white/[0.04] transition-all">
                          <div className="space-y-1">
                            <p className="text-sm font-bold text-white">Show Generations</p>
                            <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Vertical depth indicators</p>
                          </div>
                          <div 
                            onClick={() => setSettings({ ...settings, showGenerations: !settings.showGenerations })}
                            className={cn(
                              "w-12 h-6 rounded-full relative cursor-pointer transition-all",
                              settings.showGenerations ? "bg-emerald-600" : "bg-zinc-800"
                            )}
                          >
                            <div className={cn(
                              "absolute top-1 w-4 h-4 bg-white rounded-full transition-all shadow-lg",
                              settings.showGenerations ? "right-1" : "left-1"
                            )} />
                          </div>
                        </div>

                        <div className="p-6 bg-white/[0.02] rounded-3xl border border-white/5 space-y-6">
                          <div className="flex items-center justify-between">
                            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Default Expansion Depth</p>
                            <span className="text-xs font-mono font-black text-indigo-400">{settings.defaultExpandedGenerations} GEN</span>
                          </div>
                          <input 
                            type="range" 
                            min="1" 
                            max="10" 
                            value={settings.defaultExpandedGenerations}
                            onChange={(e) => setSettings({ ...settings, defaultExpandedGenerations: parseInt(e.target.value) })}
                            className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8 flex flex-col">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">AI Tree Synthesis</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                        <div className="w-20 h-20 rounded-[2rem] bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shadow-[0_0_50px_rgba(16,185,129,0.1)]">
                          <Sparkles className="text-emerald-400" size={40} />
                        </div>
                        <div className="max-w-xs">
                          <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Neural Auto-Link</h4>
                          <p className="text-sm text-zinc-500 mt-2 leading-relaxed">
                            Automatically link family members based on names, dates, and historical context using deep AI analysis.
                          </p>
                        </div>
                        <button 
                          onClick={async () => {
                            if (window.confirm("This will automatically update family relationships based on AI suggestions. Continue?")) {
                              setAnalyzing(true);
                              try {
                                const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
                                const memberData = members.map(m => ({ id: m.id, name: m.fullName, dob: m.dateOfBirth, bio: m.biography }));
                                
                                const response = await ai.models.generateContent({
                                  model: "gemini-3-flash-preview",
                                  contents: `Analyze these family members and suggest parent-child or spouse relationships. 
                                  Return ONLY a JSON array of objects with { memberId, fatherId, motherId, spouseId }. 
                                  Only suggest if you are very confident based on names and dates.
                                  
                                  Members: ${JSON.stringify(memberData)}`,
                                  config: { responseMimeType: "application/json" }
                                });

                                const updates = JSON.parse(response.text);
                                const batch = writeBatch(db);
                                let updatedCount = 0;

                                updates.forEach((update: any) => {
                                  const member = members.find(m => m.id === update.memberId);
                                  if (member) {
                                    const cleanUpdate: any = {};
                                    if (update.fatherId && update.fatherId !== member.fatherId) cleanUpdate.fatherId = update.fatherId;
                                    if (update.motherId && update.motherId !== member.motherId) cleanUpdate.motherId = update.motherId;
                                    if (update.spouseId && update.spouseId !== member.spouseId) cleanUpdate.spouseId = update.spouseId;
                                    
                                    if (Object.keys(cleanUpdate).length > 0) {
                                      batch.update(doc(db, 'members', member.id), { ...cleanUpdate, updatedAt: Date.now() });
                                      updatedCount++;
                                    }
                                  }
                                });

                                if (updatedCount > 0) {
                                  await batch.commit();
                                  alert(`Successfully updated ${updatedCount} relationships!`);
                                } else {
                                  alert("AI found no new certain relationships to update.");
                                }
                              } catch (error) {
                                console.error("AI Auto-Gen failed:", error);
                                alert("AI Auto-Generation failed.");
                              } finally {
                                setAnalyzing(false);
                              }
                            }
                          }}
                          disabled={analyzing}
                          className="px-10 py-4 bg-emerald-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-emerald-500 transition-all transform hover:-translate-y-1 disabled:opacity-50 flex items-center gap-3"
                        >
                          {analyzing ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                          Auto-Link Heritage
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                    <div className="flex items-center justify-between">
                      <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Export & Archiving</h4>
                      <div className="w-12 h-[1px] bg-white/10" />
                    </div>
                    <div className="grid grid-cols-2 gap-8">
                      <button className="p-8 bg-white/[0.02] border border-white/5 rounded-3xl flex items-center gap-6 group hover:bg-white/[0.04] transition-all">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                          <ImageIcon size={24} />
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-bold text-white">High-Res PNG</p>
                          <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Optimized for digital display</p>
                        </div>
                      </button>
                      <button className="p-8 bg-white/[0.02] border border-white/5 rounded-3xl flex items-center gap-6 group hover:bg-white/[0.04] transition-all">
                        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                          <FileText size={24} />
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-bold text-white">Family Heritage PDF</p>
                          <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Print-ready documentation</p>
                        </div>
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'media' && (
                <motion.div key="media" className="space-y-10">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Heritage Gallery</h4>
                      <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Visual documentation of family history</p>
                    </div>
                    <button className="flex items-center gap-3 px-8 py-3 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all transform hover:-translate-y-1">
                      <Plus size={18} />
                      Upload Artifact
                    </button>
                  </div>

                  <div className="grid grid-cols-5 gap-6">
                    {members.filter(m => m.photoUrl).map(m => (
                      <motion.div 
                        key={m.id} 
                        whileHover={{ y: -5 }}
                        className="aspect-[3/4] rounded-[2rem] bg-white/[0.01] border border-white/5 overflow-hidden group relative"
                      >
                        <img 
                          src={m.photoUrl} 
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 p-6 flex flex-col justify-end">
                          <p className="text-xs font-bold text-white tracking-tight">{m.fullName}</p>
                          <p className="text-[9px] text-zinc-400 font-black uppercase tracking-widest mt-1">Profile Portrait</p>
                          <div className="flex gap-3 mt-4">
                            <button className="text-[9px] font-black uppercase tracking-widest text-white/50 hover:text-white transition-colors">View</button>
                            <button className="text-[9px] font-black uppercase tracking-widest text-red-500/50 hover:text-red-500 transition-colors">Delete</button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                    <button className="aspect-[3/4] rounded-[2rem] bg-white/[0.01] border border-dashed border-white/10 flex flex-col items-center justify-center gap-4 text-zinc-700 hover:text-zinc-400 hover:bg-white/[0.02] hover:border-white/20 transition-all group">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Plus size={24} />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest">Add New Artifact</span>
                    </button>
                  </div>
                </motion.div>
              )}

              {activeTab === 'data' && (
                <motion.div key="data" className="space-y-10">
                  <div className="grid grid-cols-2 gap-8">
                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Data Portability</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <p className="text-sm text-zinc-500 leading-relaxed">Export your entire family database in standardized formats for archival or migration purposes.</p>
                      <div className="grid grid-cols-2 gap-4">
                        <button className="flex items-center justify-center gap-3 py-4 bg-white/[0.03] border border-white/5 text-zinc-400 text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-white/5 hover:text-white transition-all">
                          <Download size={16} />
                          JSON Export
                        </button>
                        <button className="flex items-center justify-center gap-3 py-4 bg-white/[0.03] border border-white/5 text-zinc-400 text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-white/5 hover:text-white transition-all">
                          <Download size={16} />
                          CSV Export
                        </button>
                      </div>
                    </div>

                    <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-8">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Import Engine</h4>
                        <div className="w-12 h-[1px] bg-white/10" />
                      </div>
                      <p className="text-sm text-zinc-500 leading-relaxed">Bulk import family members from GEDCOM or structured data files. Our AI will attempt to resolve conflicts automatically.</p>
                      <button className="w-full flex items-center justify-center gap-3 py-5 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all">
                        <Upload size={18} />
                        Initialize Import
                      </button>
                    </div>
                  </div>

                  <div className="p-10 bg-red-500/5 border border-red-500/10 rounded-[3rem] space-y-8">
                    <div className="flex items-center justify-between">
                      <h4 className="text-[10px] font-black text-red-500 uppercase tracking-[0.2em]">Danger Zone</h4>
                      <div className="w-12 h-[1px] bg-red-500/20" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-white">Purge Database</p>
                        <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Irreversibly delete all family records and media</p>
                      </div>
                      <button className="px-8 py-3 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-red-500 hover:text-white transition-all">
                        Execute Purge
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'history' && (
                <motion.div key="history" className="space-y-10">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Family Timeline</h4>
                      <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Chronological record of family milestones</p>
                    </div>
                    <button className="flex items-center gap-3 px-8 py-3 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all transform hover:-translate-y-1">
                      <Plus size={18} />
                      Add Milestone
                    </button>
                  </div>

                  <div className="relative space-y-12 before:absolute before:inset-0 before:ml-6 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-[1px] before:bg-gradient-to-b before:from-transparent before:via-white/10 before:to-transparent">
                    {familyEvents.length > 0 ? familyEvents.map((e, i) => (
                      <div key={e.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
                        <div className="flex items-center justify-center w-12 h-12 rounded-2xl border border-white/10 bg-zinc-950 text-indigo-400 shadow-2xl shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 group-hover:scale-110 transition-transform">
                          <Calendar size={20} />
                        </div>
                        <div className="w-[calc(100%-5rem)] md:w-[calc(50%-3.5rem)] p-10 bg-white/[0.01] border border-white/5 rounded-[3rem] shadow-2xl group-hover:bg-white/[0.03] transition-all">
                          <div className="flex items-center justify-between mb-4">
                            <div className="text-lg font-bold text-white tracking-tight">{e.title}</div>
                            <time className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-mono">{e.date}</time>
                          </div>
                          <div className="text-zinc-500 text-sm leading-relaxed italic">"{e.description}"</div>
                        </div>
                      </div>
                    )) : (
                      <div className="py-24 text-center space-y-6">
                        <div className="w-20 h-20 bg-white/[0.02] rounded-[2rem] flex items-center justify-center mx-auto border border-white/5">
                          <History size={32} className="text-zinc-700" />
                        </div>
                        <p className="text-sm text-zinc-600 font-black uppercase tracking-widest">The timeline is currently silent.</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {activeTab === 'users' && (
                <motion.div key="users" className="space-y-10">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Access Control</h4>
                      <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Manage administrative privileges</p>
                    </div>
                    <button className="flex items-center gap-3 px-8 py-3 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all transform hover:-translate-y-1">
                      <Plus size={18} />
                      Invite Guardian
                    </button>
                  </div>

                  <div className="bg-white/[0.01] rounded-[3rem] border border-white/5 overflow-hidden">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-white/5">
                          <th className="px-10 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Administrator</th>
                          <th className="px-10 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Privilege Level</th>
                          <th className="px-10 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Last Presence</th>
                          <th className="px-10 py-6 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/[0.02]">
                        {adminUsers.map(u => (
                          <tr key={u.uid} className="group hover:bg-white/[0.02] transition-all">
                            <td className="px-10 py-6">
                              <div className="flex items-center gap-5">
                                <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center border border-indigo-500/20 group-hover:scale-110 transition-transform">
                                  <UserCog className="text-indigo-400" size={20} />
                                </div>
                                <span className="text-sm font-bold text-white">{u.email}</span>
                              </div>
                            </td>
                            <td className="px-10 py-6">
                              <span className={cn(
                                "px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border",
                                u.role === 'admin' ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" : "bg-zinc-500/10 text-zinc-400 border-zinc-500/20"
                              )}>
                                {u.role}
                              </span>
                            </td>
                            <td className="px-10 py-6 text-xs font-mono text-zinc-500">{new Date(u.lastLogin).toLocaleString()}</td>
                            <td className="px-10 py-6 text-right">
                              <button className="p-3 hover:bg-white/5 rounded-xl text-zinc-600 hover:text-white transition-all"><Edit2 size={16} /></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activeTab === 'map' && (
                <motion.div key="map" className="space-y-10">
                  <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-10">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Heritage Distribution</h4>
                        <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Geographic spread across generations</p>
                      </div>
                      <div className="px-6 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-[10px] font-black text-indigo-400 uppercase tracking-widest">
                        {Array.from(new Set(members.map(m => m.location).filter(Boolean))).length} Global Nodes
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-8">
                      {(Object.entries(
                        members.reduce((acc, m) => {
                          if (m.location) acc[m.location] = (acc[m.location] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>)
                      ) as [string, number][]).sort((a, b) => Number(b[1]) - Number(a[1])).map(([loc, count]) => (
                        <div key={loc} className="p-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-6 group hover:bg-white/[0.04] transition-all">
                          <div className="flex items-center justify-between">
                            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                              <Map size={18} />
                            </div>
                            <span className="text-2xl font-black text-white font-mono">{count}</span>
                          </div>
                          <div className="space-y-3">
                            <p className="text-sm font-bold text-white truncate">{loc}</p>
                            <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-indigo-500" 
                                style={{ width: `${(Number(count) / (members.length || 1)) * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'ads' && (
                <motion.div key="ads" className="space-y-10">
                  <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-10">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Monetization Engine</h4>
                        <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Configure heritage support channels</p>
                      </div>
                      <button 
                        onClick={async () => {
                          setSaving(true);
                          try {
                            await setDoc(doc(db, 'settings', 'global'), {
                              ...settings,
                              updatedAt: Date.now(),
                              updatedBy: userId
                            });
                            alert('Ad settings saved successfully!');
                          } catch (error) {
                            console.error('Save failed:', error);
                            alert('Failed to save settings.');
                          } finally {
                            setSaving(false);
                          }
                        }}
                        disabled={saving}
                        className="px-8 py-3 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-indigo-500 transition-all disabled:opacity-50 flex items-center gap-3"
                      >
                        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                        Save Configuration
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-10">
                      <div className="p-8 bg-white/[0.01] border border-white/5 rounded-[2.5rem] flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-white">Enable Advertisements</p>
                          <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Toggle all ads on or off across the site</p>
                        </div>
                        <button 
                          onClick={() => setSettings({ ...settings, adsEnabled: !settings.adsEnabled })}
                          className={cn(
                            "w-14 h-7 rounded-full transition-all relative",
                            settings.adsEnabled ? "bg-indigo-600" : "bg-zinc-800"
                          )}
                        >
                          <div className={cn(
                            "absolute top-1 w-5 h-5 rounded-full bg-white transition-all shadow-xl",
                            settings.adsEnabled ? "left-8" : "left-1"
                          )} />
                        </button>
                      </div>

                      <div className="space-y-4">
                        <label className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] ml-2">Display Strategy</label>
                        <div className="grid grid-cols-4 gap-4">
                          {(['sidebar', 'footer', 'top', 'floating'] as const).map((pos) => (
                            <button
                              key={pos}
                              onClick={() => setSettings({ ...settings, adPosition: pos })}
                              className={cn(
                                "py-4 px-6 rounded-2xl border text-[10px] font-black uppercase tracking-widest transition-all",
                                settings.adPosition === pos 
                                  ? "bg-white/10 text-white border-white/20" 
                                  : "bg-white/[0.02] text-zinc-500 border-white/5 hover:border-white/10"
                              )}
                            >
                              {pos}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-4">
                          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] ml-2">Adsterra Integration</label>
                          <textarea 
                            value={settings.adsterraCode || ''}
                            onChange={(e) => setSettings({ ...settings, adsterraCode: e.target.value })}
                            placeholder="Paste your script here..."
                            className="w-full h-40 bg-white/[0.02] border border-white/5 rounded-[2rem] p-6 text-white font-mono text-xs focus:outline-none focus:bg-white/[0.04] transition-all"
                          />
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] ml-2">Custom Artifact Banner</label>
                          <div className="space-y-4">
                            <input 
                              type="text"
                              value={settings.customAdImage || ''}
                              onChange={(e) => setSettings({ ...settings, customAdImage: e.target.value })}
                              placeholder="Banner Image URL"
                              className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-4 text-xs text-white focus:outline-none focus:bg-white/[0.04] transition-all"
                            />
                            <input 
                              type="text"
                              value={settings.customAdLink || ''}
                              onChange={(e) => setSettings({ ...settings, customAdLink: e.target.value })}
                              placeholder="Destination Link"
                              className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-4 text-xs text-white focus:outline-none focus:bg-white/[0.04] transition-all"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'approvals' && (
                <motion.div key="approvals" className="space-y-10">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Pending Submissions</h4>
                      <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Review public contributions to the heritage</p>
                    </div>
                    <div className="px-6 py-2 bg-amber-500/10 border border-amber-500/20 rounded-full text-[10px] font-black text-amber-500 uppercase tracking-widest">
                      {members.filter(m => m.status === 'pending').length} Awaiting Review
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-6">
                    {members.filter(m => m.status === 'pending').length === 0 ? (
                      <div className="py-24 text-center space-y-6">
                        <div className="w-20 h-20 bg-white/[0.02] rounded-[2rem] flex items-center justify-center mx-auto border border-white/5">
                          <CheckCircle2 size={32} className="text-zinc-700" />
                        </div>
                        <p className="text-sm text-zinc-600 font-black uppercase tracking-widest">All submissions have been reconciled.</p>
                      </div>
                    ) : (
                      members.filter(m => m.status === 'pending').map(m => (
                        <div key={m.id} className="p-8 bg-white/[0.01] border border-white/5 rounded-[3rem] flex items-center justify-between group hover:bg-white/[0.02] transition-all">
                          <div className="flex items-center gap-6">
                            <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-white/5 overflow-hidden">
                              <img src={m.photoUrl || `https://picsum.photos/seed/${m.id}/200`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            </div>
                            <div>
                              <h5 className="text-lg font-bold text-white tracking-tight">{m.fullName}</h5>
                              <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest mt-1">Submitted on {new Date(m.createdAt).toLocaleDateString()}</p>
                            </div>
                          </div>
                          <div className="flex gap-4">
                            <button 
                              onClick={async () => {
                                try {
                                  await setDoc(doc(db, 'members', m.id), {
                                    ...m,
                                    status: 'approved',
                                    updatedAt: Date.now(),
                                    updatedBy: userId
                                  });
                                } catch (error) {
                                  console.error("Approve failed:", error);
                                  alert("Failed to approve.");
                                }
                              }}
                              className="px-8 py-3 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl shadow-2xl hover:bg-emerald-500 transition-all transform hover:-translate-y-1"
                            >
                              Approve
                            </button>
                            <button 
                              onClick={async () => {
                                if (!confirm("Are you sure you want to reject this submission?")) return;
                                try {
                                  await deleteDoc(doc(db, 'members', m.id));
                                } catch (error) {
                                  console.error("Reject failed:", error);
                                  alert("Failed to reject.");
                                }
                              }}
                              className="px-8 py-3 bg-white/5 border border-white/10 text-zinc-400 text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-red-500/10 hover:text-red-500 hover:border-red-500/20 transition-all"
                            >
                              Reject
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
              {activeTab === 'security' && (
                <motion.div key="security" className="space-y-10">
                  <div className="p-10 bg-white/[0.01] rounded-[3rem] border border-white/5 space-y-10">
                    <div className="space-y-1">
                      <h4 className="text-2xl font-black text-white tracking-tighter font-serif italic">Security Protocol</h4>
                      <p className="text-[10px] text-zinc-600 font-black uppercase tracking-[0.2em]">Manage heritage access & authentication</p>
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                      <div className="p-8 bg-white/[0.01] border border-white/5 rounded-[2.5rem] flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-white">Google Authentication</p>
                          <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Allow administrators to sign in via Google</p>
                        </div>
                        <button className="w-14 h-7 rounded-full bg-indigo-600 relative transition-all">
                          <div className="absolute right-1 top-1 w-5 h-5 rounded-full bg-white shadow-xl" />
                        </button>
                      </div>

                      <div className="p-8 bg-white/[0.01] border border-white/5 rounded-[2.5rem] flex items-center justify-between opacity-50">
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-white">Two-Factor Authentication</p>
                          <p className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Require secondary verification for all admin actions</p>
                        </div>
                        <button className="w-14 h-7 rounded-full bg-zinc-800 relative transition-all">
                          <div className="absolute left-1 top-1 w-5 h-5 rounded-full bg-zinc-600" />
                        </button>
                      </div>
                    </div>

                    <div className="p-8 bg-rose-500/5 border border-rose-500/10 rounded-[2.5rem] space-y-4">
                      <div className="flex items-center gap-3 text-rose-500">
                        <ShieldAlert size={20} />
                        <p className="text-xs font-black uppercase tracking-widest">Advanced Guard</p>
                      </div>
                      <p className="text-sm text-rose-200/60 leading-relaxed">
                        Security protocols are enforced at the database level. Any unauthorized attempt to modify the family heritage will be logged and blocked.
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {isMemberFormOpen && (
          <MemberForm
            members={members}
            editingMember={editingMember}
            onClose={() => {
              setIsMemberFormOpen(false);
              setEditingMember(null);
            }}
            onSuccess={() => {
              setIsMemberFormOpen(false);
              setEditingMember(null);
            }}
            primaryColor={settings.primaryColor}
          />
        )}
      </motion.div>
    </div>
  );
};
