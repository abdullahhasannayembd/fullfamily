import React, { useState } from 'react';
import { auth } from '../firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import { LogIn, UserPlus, LogOut, User as UserIcon } from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  primaryColor?: string;
}

export const Auth: React.FC<Props> = ({ primaryColor = "#10b981" }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return unsubscribe;
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Map "admin" shorthand to a valid email format for Firebase
    const finalEmail = email === 'admin' ? 'admin@family.tree' : email;
    const finalPassword = password;

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, finalEmail, finalPassword);
      } else {
        await createUserWithEmailAndPassword(auth, finalEmail, finalPassword);
      }
    } catch (err: any) {
      // If admin login fails because user doesn't exist, try to create it automatically
      if (email === 'admin' && err.code === 'auth/user-not-found') {
        try {
          await createUserWithEmailAndPassword(auth, finalEmail, finalPassword);
          return;
        } catch (createErr: any) {
          setError(createErr.message);
        }
      }
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  const handleQuickAdmin = () => {
    setEmail('admin');
    setPassword('admin');
    setIsLogin(true);
  };

  if (user) {
    const isAdmin = user.uid === 'gkBgLGvF8NNW2u1WL0Y9BqP1bom1' || user.email === 'admin@family.tree';
    return (
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-white/10 rounded-full border border-white/20">
          <UserIcon size={16} style={{ color: primaryColor }} />
          <span className="text-sm font-medium text-white truncate max-w-[150px]">
            {isAdmin ? 'Administrator' : user.email}
          </span>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg transition-all text-sm font-medium"
        >
          <LogOut size={16} />
          Logout
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 w-full max-w-sm p-6 bg-zinc-900/50 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl">
      <div className="flex gap-2 p-1 bg-black/40 rounded-xl border border-white/5">
        <button
          onClick={() => setIsLogin(true)}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all",
            isLogin ? "text-white shadow-lg" : "text-zinc-400 hover:text-white"
          )}
          style={isLogin ? { backgroundColor: primaryColor } : {}}
        >
          <LogIn size={16} />
          Login
        </button>
        <button
          onClick={() => setIsLogin(false)}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all",
            !isLogin ? "text-white shadow-lg" : "text-zinc-400 hover:text-white"
          )}
          style={!isLogin ? { backgroundColor: primaryColor } : {}}
        >
          <UserPlus size={16} />
          Sign Up
        </button>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="space-y-1">
          <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider ml-1">Email / Username</label>
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder:text-zinc-600 focus:outline-none transition-all"
            style={{ '--tw-ring-color': `${primaryColor}80` } as any}
            placeholder="admin or email@example.com"
            required
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider ml-1">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder:text-zinc-600 focus:outline-none transition-all"
            style={{ '--tw-ring-color': `${primaryColor}80` } as any}
            placeholder="••••••••"
            required
          />
        </div>
        {error && (
          <p className="text-xs text-red-400 bg-red-400/10 p-3 rounded-lg border border-red-400/20">
            {error}
          </p>
        )}
        <div className="flex flex-col gap-2">
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg transition-all transform active:scale-[0.98]"
            style={{ backgroundColor: primaryColor, boxShadow: `0 10px 15px -3px ${primaryColor}33` }}
          >
            {loading ? 'Processing...' : isLogin ? 'Login' : 'Create Account'}
          </button>
          <button
            type="button"
            onClick={handleQuickAdmin}
            className="w-full py-2 text-xs font-bold text-zinc-500 transition-colors uppercase tracking-widest"
            style={{ color: `${primaryColor}cc` }}
          >
            Quick Admin Login
          </button>
        </div>
      </form>
    </div>
  );
};
