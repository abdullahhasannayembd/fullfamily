import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as d3 from 'd3';
import { FamilyMember, SiteSettings } from '../types';
import { 
  User, 
  Heart, 
  Baby, 
  ChevronDown, 
  ChevronUp, 
  ZoomIn, 
  ZoomOut, 
  Maximize, 
  Target,
  Plus,
  Minus,
  Maximize2
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  members: FamilyMember[];
  onMemberClick: (member: FamilyMember) => void;
  selectedMemberId?: string;
  primaryColor?: string;
  settings?: SiteSettings;
}

interface TreeNode extends d3.HierarchyPointNode<FamilyMember> {
  _children?: TreeNode[] | null;
}

export const FamilyTree: React.FC<Props> = ({ members, onMemberClick, selectedMemberId, primaryColor = "#10b981", settings }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const gRef = useRef<SVGGElement>(null);
  const zoomRef = useRef<any>(null);
  const [collapsedIds, setCollapsedIds] = useState<Set<string>>(new Set());

  const [searchQuery, setSearchQuery] = useState("");
  const hasInitializedRef = useRef(false);

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    if (!query) return;
    
    const matched = members.find(m => m.fullName.toLowerCase().includes(query.toLowerCase()));
    if (matched && svgRef.current && zoomRef.current && containerRef.current) {
      const node = d3.select(svgRef.current).select(`.node-${matched.id}`);
      if (!node.empty()) {
        const d = node.datum() as TreeNode;
        const width = containerRef.current.clientWidth;
        const height = containerRef.current.clientHeight;
        
        d3.select(svgRef.current).transition().duration(1000).call(
          zoomRef.current.transform,
          d3.zoomIdentity.translate(width / 2 - d.x * 1, height / 2 - d.y * 1).scale(1)
        );
        onMemberClick(matched);
      }
    }
  }, [members, onMemberClick]);

  const handleZoomIn = () => {
    if (svgRef.current && zoomRef.current) {
      d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 1.4);
    }
  };

  const handleZoomOut = () => {
    if (svgRef.current && zoomRef.current) {
      d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 0.7);
    }
  };

  const handleFitToScreen = useCallback(() => {
    if (!svgRef.current || !zoomRef.current || !containerRef.current || !gRef.current) return;
    
    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;
    const g = d3.select(gRef.current);
    const bounds = (g.node() as SVGGElement).getBBox();
    
    if (bounds.width === 0 || bounds.height === 0) return;

    const fullWidth = bounds.width;
    const fullHeight = bounds.height;
    const midX = bounds.x + fullWidth / 2;
    const midY = bounds.y + fullHeight / 2;
    
    const scale = 0.85 / Math.max(fullWidth / width, fullHeight / height);
    const clampedScale = Math.max(0.05, Math.min(2, scale));
    
    d3.select(svgRef.current).transition().duration(750).call(
      zoomRef.current.transform, 
      d3.zoomIdentity.translate(width / 2 - midX * clampedScale, height / 2 - midY * clampedScale).scale(clampedScale)
    );
  }, []);

  const handleCenterOnSelected = useCallback(() => {
    if (!selectedMemberId || !svgRef.current || !zoomRef.current || !containerRef.current) return;
    
    const node = d3.select(svgRef.current).select(`.node-${selectedMemberId}`);
    if (!node.empty()) {
      const d = node.datum() as TreeNode;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      
      d3.select(svgRef.current).transition().duration(750).call(
        zoomRef.current.transform,
        d3.zoomIdentity.translate(width / 2 - d.x * 1, height / 2 - d.y * 1).scale(1)
      );
    }
  }, [selectedMemberId]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;
      
      if (e.key === '+' || e.key === '=') handleZoomIn();
      if (e.key === '-' || e.key === '_') handleZoomOut();
      if (e.key === '0') handleFitToScreen();
      if (e.key === 'f' && selectedMemberId) handleCenterOnSelected();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedMemberId, handleFitToScreen, handleCenterOnSelected]);

  const [hoveredMemberId, setHoveredMemberId] = useState<string | null>(null);

  const getLineage = useCallback((memberId: string) => {
    const ancestors = new Set<string>();
    const descendants = new Set<string>();
    
    const findAncestors = (id: string) => {
      const m = members.find(member => member.id === id);
      if (!m) return;
      if (m.fatherId) { ancestors.add(m.fatherId); findAncestors(m.fatherId); }
      if (m.motherId) { ancestors.add(m.motherId); findAncestors(m.motherId); }
    };

    const findDescendants = (id: string) => {
      members.forEach(m => {
        if (m.fatherId === id || m.motherId === id) {
          descendants.add(m.id);
          findDescendants(m.id);
        }
      });
    };

    findAncestors(memberId);
    findDescendants(memberId);
    return { ancestors, descendants };
  }, [members]);

  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    if (!containerRef.current) return;
    
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) {
        setDimensions({
          width: entries[0].contentRect.width,
          height: entries[0].contentRect.height
        });
      }
    });
    
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current || members.length === 0 || dimensions.width === 0) return;

    const { width, height } = dimensions;

    const svg = d3.select(svgRef.current);
    
    if (!zoomRef.current) {
      zoomRef.current = d3.zoom<SVGSVGElement, unknown>()
        .scaleExtent([0.05, 4])
        .on("zoom", (event) => {
          d3.select(gRef.current).attr("transform", event.transform);
        });
      svg.call(zoomRef.current);
    }

    const g = d3.select(gRef.current);
    
    // Clear previous content to avoid duplicates during re-renders
    // g.selectAll("*").remove(); // Actually, D3 join handles this better if we use data keys

    const virtualRootId = "VIRTUAL_ROOT";
    const sortedMembers = [...members].sort((a, b) => {
      const aHasParents = !!(a.fatherId || a.motherId);
      const bHasParents = !!(b.fatherId || b.motherId);
      if (aHasParents !== bHasParents) return aHasParents ? 1 : -1;
      const dateA = a.dateOfBirth ? new Date(a.dateOfBirth).getTime() : Infinity;
      const dateB = b.dateOfBirth ? new Date(b.dateOfBirth).getTime() : Infinity;
      return dateA - dateB;
    });

    const dataWithVirtualRoot = [
      ...sortedMembers,
      { id: virtualRootId, fatherId: null, motherId: null, fullName: "Virtual Root" } as any
    ];

    const stratify = d3.stratify<any>()
      .id(d => d.id)
      .parentId(d => {
        if (d.id === virtualRootId) return null;
        if (d.fatherId) return d.fatherId;
        if (d.motherId) return d.motherId;
        // Try to find a spouse who has parents
        const spouse = members.find(m => m.id === d.spouseId || m.spouseId === d.id);
        if (spouse && (spouse.fatherId || spouse.motherId)) return spouse.fatherId || spouse.motherId;
        return virtualRootId;
      });

    try {
      const root = stratify(dataWithVirtualRoot) as any;
      
      const nodeWidth = 260;
      const nodeHeight = 320;
      
      const treeLayout = d3.tree<any>()
        .nodeSize([nodeWidth, nodeHeight])
        .separation((a, b) => a.parent === b.parent ? 1.3 : 2.8);

      const visibleRoot = root.copy();
      const applyCollapse = (node: any) => {
        if (collapsedIds.has(node.data.id)) {
          node._children = node.children;
          node.children = null;
        } else if (node.children) {
          node.children.forEach(applyCollapse);
        }
      };
      applyCollapse(visibleRoot);

      treeLayout(visibleRoot);

      const descendants = visibleRoot.descendants().filter((d: any) => d.id !== virtualRootId) as TreeNode[];
      const transition = svg.transition().duration(750).ease(d3.easeCubicInOut);

      // Lineage info for highlighting
      const lineage = hoveredMemberId ? getLineage(hoveredMemberId) : { ancestors: new Set(), descendants: new Set() };

      // --- Links ---
      const allLinks: any[] = [];
      descendants.forEach(d => {
        if (d.data.fatherId) {
          const fatherNode = descendants.find(n => n.data.id === d.data.fatherId);
          if (fatherNode) allLinks.push({ id: `${fatherNode.id}-${d.id}`, source: fatherNode, target: d, type: 'father' });
        }
        if (d.data.motherId) {
          const motherNode = descendants.find(n => n.data.id === d.data.motherId);
          if (motherNode) allLinks.push({ id: `${motherNode.id}-${d.id}`, source: motherNode, target: d, type: 'mother' });
        }
        if (!d.data.fatherId && !d.data.motherId && d.parent && d.parent.id !== virtualRootId) {
          allLinks.push({ id: `${d.parent.id}-${d.id}`, source: d.parent, target: d, type: 'default' });
        }
      });

      const linkSelection = g.selectAll<SVGPathElement, any>(".link")
        .data(allLinks, d => d.id);

      linkSelection.exit().transition(transition as any).style("opacity", 0).remove();

      const linkEnter = linkSelection.enter()
        .append("path")
        .attr("class", "link")
        .attr("fill", "none")
        .attr("stroke-width", 2)
        .attr("opacity", 0);

      linkSelection.merge(linkEnter as any)
        .transition(transition as any)
        .attr("opacity", d => {
          if (!hoveredMemberId) return 0.4;
          const isRelated = d.source.id === hoveredMemberId || d.target.id === hoveredMemberId || 
                           (lineage.ancestors.has(d.source.id) && lineage.ancestors.has(d.target.id)) ||
                           (lineage.descendants.has(d.source.id) && lineage.descendants.has(d.target.id));
          return isRelated ? 1 : 0.1;
        })
        .attr("stroke-width", d => {
          if (!hoveredMemberId) return 2;
          const isRelated = d.source.id === hoveredMemberId || d.target.id === hoveredMemberId;
          return isRelated ? 4 : 2;
        })
        .attr("stroke", d => {
          if (hoveredMemberId) {
            const isRelated = d.source.id === hoveredMemberId || d.target.id === hoveredMemberId || 
                             (lineage.ancestors.has(d.source.id) && lineage.ancestors.has(d.target.id)) ||
                             (lineage.descendants.has(d.source.id) && lineage.descendants.has(d.target.id));
            if (isRelated) return primaryColor;
          }
          return d.type === 'father' ? "#3b82f6" : d.type === 'mother' ? "#f472b6" : "#3f3f46";
        })
        .attr("d", d => {
          const midY = (d.source.y + d.target.y) / 2;
          return `M${d.source.x},${d.source.y} L${d.source.x},${midY} L${d.target.x},${midY} L${d.target.x},${d.target.y}`;
        });

      // --- Spouse Links ---
      const spouseLinks: any[] = [];
      descendants.forEach(d => {
        if (d.data.spouseId) {
          const spouseNode = descendants.find(n => n.data.id === d.data.spouseId);
          if (spouseNode && spouseNode.id! > d.id!) {
            spouseLinks.push({ id: `spouse-${d.id}-${spouseNode.id}`, source: d, target: spouseNode });
          }
        }
      });

      const spouseSelection = g.selectAll<SVGPathElement, any>(".spouse-link")
        .data(spouseLinks, d => d.id);

      spouseSelection.exit().transition(transition as any).style("opacity", 0).remove();

      const spouseEnter = spouseSelection.enter()
        .append("path")
        .attr("class", "spouse-link")
        .attr("fill", "none")
        .attr("stroke", "#f43f5e")
        .attr("stroke-width", 2)
        .attr("stroke-dasharray", "6,4")
        .attr("opacity", 0);

      spouseSelection.merge(spouseEnter as any)
        .transition(transition as any)
        .attr("opacity", d => {
          if (!hoveredMemberId) return 0.6;
          return (d.source.id === hoveredMemberId || d.target.id === hoveredMemberId) ? 1 : 0.1;
        })
        .attr("stroke-width", d => (d.source.id === hoveredMemberId || d.target.id === hoveredMemberId) ? 4 : 2)
        .attr("d", d => {
          const midY = (d.source.y + d.target.y) / 2;
          return `M${d.source.x},${d.source.y} C${d.source.x},${midY - 40} ${d.target.x},${midY - 40} ${d.target.x},${d.target.y}`;
        });

      // --- Nodes ---
      const nodeSelection = g.selectAll<SVGGElement, TreeNode>(".node")
        .data(descendants, d => d.id as string);

      nodeSelection.exit().transition(transition as any)
        .attr("transform", (d: any) => `translate(${d.x},${d.y}) scale(0)`)
        .style("opacity", 0)
        .remove();

      const nodeEnter = nodeSelection.enter()
        .append("g")
        .attr("class", d => `node node-${d.data.id}`)
        .attr("transform", d => `translate(${d.x},${d.y}) scale(0)`)
        .style("opacity", 0)
        .on("click", (event, d) => {
          if (event.target.closest('.collapse-toggle')) return;
          onMemberClick(d.data);
        })
        .on("mouseenter", (event, d) => {
          setHoveredMemberId(d.data.id);
        })
        .on("mouseleave", () => {
          setHoveredMemberId(null);
        })
        .style("cursor", "pointer");

      // Card Background
      nodeEnter.append("rect")
        .attr("x", -110)
        .attr("y", -60)
        .attr("width", 220)
        .attr("height", 120)
        .attr("rx", 12)
        .attr("class", "node-rect")
        .attr("fill", "#09090b")
        .attr("stroke", "#18181b")
        .attr("stroke-width", 1);

      // Card Content
      nodeEnter.each(function(d: TreeNode) {
        const group = d3.select(this);
        
        // Avatar
        const avatarGroup = group.append("g").attr("class", "avatar-group");
        
        avatarGroup.append("rect")
          .attr("x", -95)
          .attr("y", -45)
          .attr("width", 50)
          .attr("height", 50)
          .attr("rx", 8)
          .attr("fill", "#18181b")
          .attr("stroke", "#27272a")
          .attr("stroke-width", 1);

        if (d.data.photoUrl) {
          avatarGroup.append("defs")
            .append("clipPath")
            .attr("id", `clip-${d.data.id}`)
            .append("rect")
            .attr("x", -95)
            .attr("y", -45)
            .attr("width", 50)
            .attr("height", 50)
            .attr("rx", 8);

          avatarGroup.append("image")
            .attr("xlink:href", d.data.photoUrl)
            .attr("x", -95)
            .attr("y", -45)
            .attr("width", 50)
            .attr("height", 50)
            .attr("preserveAspectRatio", "xMidYMid slice")
            .attr("clip-path", `url(#clip-${d.data.id})`);
        } else {
          avatarGroup.append("text")
            .attr("x", -70)
            .attr("y", -15)
            .attr("text-anchor", "middle")
            .attr("fill", "#3f3f46")
            .attr("font-size", "16px")
            .text("👤");
        }

        // Text Info
        const infoGroup = group.append("g").attr("transform", "translate(-35, -35)");
        
        infoGroup.append("text")
          .attr("class", "node-name")
          .attr("y", 10)
          .attr("fill", "white")
          .attr("font-weight", "700")
          .attr("font-size", "13px")
          .attr("font-family", "Inter, sans-serif")
          .text((d: any) => d.data.fullName.length > 20 ? d.data.fullName.substring(0, 18) + "..." : d.data.fullName);

        infoGroup.append("text")
          .attr("class", "node-occupation")
          .attr("y", 28)
          .attr("fill", "#71717a")
          .attr("font-size", "9px")
          .attr("font-weight", "600")
          .attr("text-transform", "uppercase")
          .attr("letter-spacing", "0.05em")
          .text((d: any) => d.data.occupation || "Family Member");
          
        if (d.data.dateOfBirth) {
          infoGroup.append("text")
            .attr("class", "node-dates")
            .attr("y", 45)
            .attr("fill", "#3f3f46")
            .attr("font-size", "10px")
            .attr("font-family", "JetBrains Mono, monospace")
            .text((d: any) => {
              const birth = new Date(d.data.dateOfBirth).getFullYear();
              const death = d.data.dateOfDeath ? new Date(d.data.dateOfDeath).getFullYear() : 'Present';
              return `${birth} — ${death}`;
            });
        }

        // Status indicator
        if (d.data.status === 'pending') {
          group.append("circle")
            .attr("cx", 95)
            .attr("cy", -45)
            .attr("r", 4)
            .attr("fill", "#f59e0b");
        }
      });

      const nodeUpdate = nodeSelection.merge(nodeEnter as any);
      
      nodeUpdate.transition(transition as any)
        .attr("transform", d => `translate(${d.x},${d.y}) scale(1)`)
        .style("opacity", d => {
          if (!hoveredMemberId) return 1;
          const isRelated = d.id === hoveredMemberId || lineage.ancestors.has(d.id as string) || lineage.descendants.has(d.id as string);
          return isRelated ? 1 : 0.2;
        });

      nodeUpdate.select(".node-rect")
        .transition(transition as any)
        .attr("fill", (d: any) => d.data.id === selectedMemberId ? "#0c0c0e" : "#09090b")
        .attr("stroke", (d: any) => {
          if (d.data.id === selectedMemberId) return primaryColor;
          if (hoveredMemberId === d.data.id) return primaryColor;
          if (lineage.ancestors.has(d.data.id)) return "#3b82f6";
          if (lineage.descendants.has(d.data.id)) return "#10b981";
          return "#18181b";
        })
        .attr("stroke-width", (d: any) => (d.data.id === selectedMemberId || hoveredMemberId === d.data.id) ? 2 : 1);

      // Collapse Toggles
      nodeUpdate.each(function(d: TreeNode) {
        const group = d3.select(this);
        group.select(".collapse-toggle").remove();

        const originalNode = root.descendants().find((n: any) => n.id === d.id) as any;
        const hasChildren = originalNode && originalNode.children && originalNode.children.length > 0;
        const hasHiddenChildren = originalNode && originalNode._children && originalNode._children.length > 0;

        if (hasChildren || hasHiddenChildren) {
          const toggle = group.append("g")
            .attr("class", "collapse-toggle")
            .attr("transform", "translate(0, 60)")
            .on("click", (event, d: any) => {
              event.stopPropagation();
              if (collapsedIds.has(d.data.id)) {
                collapsedIds.delete(d.data.id);
              } else {
                collapsedIds.add(d.data.id);
              }
              setCollapsedIds(new Set(collapsedIds));
            });

          toggle.append("rect")
            .attr("x", -12)
            .attr("y", -12)
            .attr("width", 24)
            .attr("height", 24)
            .attr("rx", 6)
            .attr("fill", "#09090b")
            .attr("stroke", "#18181b")
            .attr("stroke-width", 1);

          toggle.append("text")
            .attr("text-anchor", "middle")
            .attr("y", 4)
            .attr("fill", "white")
            .attr("font-size", "12px")
            .attr("font-weight", "bold")
            .text(collapsedIds.has(d.data.id) ? "+" : "−");
        }
      });

      // Initial center if no selection
      if (descendants.length > 0 && !selectedMemberId && !hoveredMemberId && !hasInitializedRef.current) {
        handleFitToScreen();
        hasInitializedRef.current = true;
      }

    } catch (err) {
      console.error("D3 Error:", err);
    }
  }, [members, selectedMemberId, onMemberClick, collapsedIds, settings, primaryColor, hoveredMemberId, getLineage, dimensions, handleFitToScreen]);


  return (
    <div ref={containerRef} className="w-full h-full bg-zinc-950 relative overflow-hidden rounded-3xl border border-white/5 shadow-2xl">
      <svg ref={svgRef} className="w-full h-full outline-none cursor-grab active:cursor-grabbing">
        <g ref={gRef} />
      </svg>
      
      {/* Navigation Controls */}
      <div className="absolute top-6 left-6 right-6 flex items-start justify-between pointer-events-none">
        <div className="flex flex-col gap-4 pointer-events-auto w-full max-w-xs">
          <div className="relative group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Target size={16} className="text-zinc-500 group-focus-within:text-white transition-colors" style={{ color: searchQuery ? primaryColor : undefined }} />
            </div>
            <input 
              type="text"
              placeholder="Search family member..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full bg-zinc-900/80 backdrop-blur-xl border border-white/10 rounded-2xl pl-12 pr-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 transition-all"
              style={{ '--tw-ring-color': `${primaryColor}40` } as any}
            />
          </div>
        </div>

        <div className="flex flex-col gap-2 pointer-events-auto">
          <div className="flex flex-col bg-zinc-900/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
          <button 
            onClick={handleZoomIn}
            className="p-3 hover:bg-white/10 text-zinc-400 hover:text-white transition-all border-b border-white/5"
            title="Zoom In (+)"
          >
            <Plus size={20} />
          </button>
          <button 
            onClick={handleZoomOut}
            className="p-3 hover:bg-white/10 text-zinc-400 hover:text-white transition-all border-b border-white/5"
            title="Zoom Out (-)"
          >
            <Minus size={20} />
          </button>
          <button 
            onClick={handleFitToScreen}
            className="p-3 hover:bg-white/10 text-zinc-400 hover:text-white transition-all border-b border-white/5"
            title="Fit to Screen (0)"
          >
            <Maximize2 size={18} />
          </button>
          <button 
            onClick={handleCenterOnSelected}
            disabled={!selectedMemberId}
            className={cn(
              "p-3 transition-all",
              selectedMemberId ? "hover:bg-white/10 text-zinc-400 hover:text-white" : "opacity-30 cursor-not-allowed text-zinc-600"
            )}
            title="Center on Selected (F)"
          >
            <Target size={20} />
          </button>
        </div>

        <div className="flex flex-col bg-zinc-900/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
          <button 
            onClick={() => setCollapsedIds(new Set())}
            className="px-4 py-2.5 hover:bg-white/10 text-[10px] font-black text-zinc-400 hover:text-white transition-all border-b border-white/5 uppercase tracking-widest"
          >
            Expand All
          </button>
          <button 
            onClick={() => {
              const allWithChildren = members.filter(m => members.some(child => child.fatherId === m.id || child.motherId === m.id));
              setCollapsedIds(new Set(allWithChildren.map(m => m.id)));
            }}
            className="px-4 py-2.5 hover:bg-white/10 text-[10px] font-black text-zinc-400 hover:text-white transition-all uppercase tracking-widest"
          >
            Collapse All
          </button>
        </div>
      </div>
    </div>

    {/* Legend */}
      <div className="absolute bottom-6 left-6 flex flex-col gap-2 pointer-events-none">
        <div className="flex items-center gap-3 bg-zinc-900/60 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/5 shadow-xl">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: primaryColor, boxShadow: `0 0 12px ${primaryColor}80` }} />
            <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Active</span>
          </div>
          <div className="w-px h-3 bg-white/10" />
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-blue-500" />
            <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Paternal</span>
          </div>
          <div className="w-px h-3 bg-white/10" />
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-pink-400" />
            <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Maternal</span>
          </div>
          <div className="w-px h-3 bg-white/10" />
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 border-t-2 border-dashed border-rose-500" />
            <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Spouse</span>
          </div>
        </div>
      </div>
    </div>
  );
};
