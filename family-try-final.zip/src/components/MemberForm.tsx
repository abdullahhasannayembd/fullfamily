import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { FamilyMember } from '../types';
import { db, storage, auth } from '../firebase';
import { collection, addDoc, updateDoc, doc, writeBatch } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { X, Upload, UserPlus, Save, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

const memberSchema = z.object({
  fullName: z.string().min(2, "Name is too short"),
  fatherId: z.string().optional(),
  motherId: z.string().optional(),
  spouseId: z.string().optional(),
  dateOfBirth: z.string().optional(),
  dateOfDeath: z.string().optional(),
  occupation: z.string().optional(),
  biography: z.string().optional(),
  location: z.string().optional(),
  generation: z.number().optional(),
  branch: z.string().optional(),
});

type MemberFormData = z.infer<typeof memberSchema>;

interface Props {
  members: FamilyMember[];
  editingMember?: FamilyMember | null;
  onClose: () => void;
  onSuccess: () => void;
  primaryColor?: string;
  publicModeEnabled?: boolean;
}

export const MemberForm: React.FC<Props> = ({ members, editingMember, onClose, onSuccess, primaryColor = "#10b981", publicModeEnabled }) => {
  const [loading, setLoading] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(editingMember?.photoUrl || null);

  const { register, handleSubmit, formState: { errors } } = useForm<MemberFormData>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      fullName: editingMember?.fullName || '',
      fatherId: editingMember?.fatherId || '',
      motherId: editingMember?.motherId || '',
      spouseId: editingMember?.spouseId || '',
      dateOfBirth: editingMember?.dateOfBirth || '',
      dateOfDeath: editingMember?.dateOfDeath || '',
      occupation: editingMember?.occupation || '',
      biography: editingMember?.biography || '',
      location: editingMember?.location || '',
      generation: editingMember?.generation || 1,
      branch: editingMember?.branch || '',
    }
  });

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: MemberFormData) => {
    if (!auth.currentUser && !publicModeEnabled) return;
    setLoading(true);

    try {
      let photoUrl = editingMember?.photoUrl || '';

      if (photoFile) {
        const storageRef = ref(storage, `members/${Date.now()}_${photoFile.name}`);
        await uploadBytes(storageRef, photoFile);
        photoUrl = await getDownloadURL(storageRef);
      }

      const batch = writeBatch(db);
      const memberData = {
        ...data,
        photoUrl,
        updatedAt: Date.now(),
        status: auth.currentUser ? 'approved' : 'pending',
      };

      let memberId = editingMember?.id;

      if (editingMember) {
        const memberRef = doc(db, 'members', editingMember.id);
        batch.update(memberRef, memberData);
        
        // Handle reciprocal spouse update
        // If spouse changed, clear old spouse's reference
        if (editingMember.spouseId && editingMember.spouseId !== data.spouseId) {
          const oldSpouseRef = doc(db, 'members', editingMember.spouseId);
          batch.update(oldSpouseRef, { spouseId: '', updatedAt: Date.now() });
        }
      } else {
        const newMemberRef = doc(collection(db, 'members'));
        memberId = newMemberRef.id;
        batch.set(newMemberRef, {
          ...memberData,
          createdBy: auth.currentUser?.uid || 'public',
          createdAt: Date.now(),
        });
      }

      // If a new spouse is selected, update them to point back to this member
      if (data.spouseId && memberId) {
        const newSpouseRef = doc(db, 'members', data.spouseId);
        batch.update(newSpouseRef, { spouseId: memberId, updatedAt: Date.now() });
      }

      await batch.commit();
      
      if (!auth.currentUser) {
        alert("Member submitted for approval!");
      }
      
      onSuccess();
    } catch (err) {
      console.error("Error saving member:", err);
      alert("Failed to save member. Check console for details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-[#050505] w-full max-w-2xl rounded-[2rem] border border-white/5 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl border" style={{ backgroundColor: `${primaryColor}1a`, borderColor: `${primaryColor}33` }}>
              <UserPlus style={{ color: primaryColor }} size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white tracking-tighter font-serif italic">
                {editingMember ? 'Refine Profile' : 'New Heritage Entry'}
              </h2>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 mt-1">Archive Documentation</p>
            </div>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-white/5 rounded-2xl text-zinc-500 hover:text-white transition-all">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-10 overflow-y-auto flex-1 space-y-12 custom-scrollbar">
          {/* Photo Upload Section */}
          <div className="flex flex-col items-center gap-6">
            <div className="relative group">
              <div className="w-40 h-40 rounded-[2.5rem] bg-white/[0.02] border-2 border-dashed border-white/10 flex items-center justify-center overflow-hidden transition-all group-hover:border-white/20" style={{ borderColor: `${primaryColor}33` }}>
                {photoPreview ? (
                  <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  <Upload className="text-zinc-700 transition-colors group-hover:text-white" size={40} />
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </div>
            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Upload Portrait</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Full Name</label>
              <input
                {...register('fullName')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                placeholder="e.g. Alexander Hamilton"
              />
              {errors.fullName && <p className="text-[10px] font-bold text-red-500/80 ml-1">{errors.fullName.message}</p>}
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Date of Birth</label>
              <input
                type="date"
                {...register('dateOfBirth')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all font-mono"
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Date of Death</label>
              <input
                type="date"
                {...register('dateOfDeath')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all font-mono"
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Father</label>
              <select
                {...register('fatherId')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all appearance-none cursor-pointer"
              >
                <option value="" className="bg-[#050505]">None</option>
                {members.filter(m => m.id !== editingMember?.id).map(m => (
                  <option key={m.id} value={m.id} className="bg-[#050505]">{m.fullName}</option>
                ))}
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Mother</label>
              <select
                {...register('motherId')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all appearance-none cursor-pointer"
              >
                <option value="" className="bg-[#050505]">None</option>
                {members.filter(m => m.id !== editingMember?.id).map(m => (
                  <option key={m.id} value={m.id} className="bg-[#050505]">{m.fullName}</option>
                ))}
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Spouse</label>
              <select
                {...register('spouseId')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all appearance-none cursor-pointer"
              >
                <option value="" className="bg-[#050505]">None</option>
                {members.filter(m => m.id !== editingMember?.id).map(m => (
                  <option key={m.id} value={m.id} className="bg-[#050505]">{m.fullName}</option>
                ))}
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Occupation</label>
              <input
                {...register('occupation')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                placeholder="e.g. Historian"
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Location</label>
              <input
                {...register('location')}
                className="w-full px-5 py-4 bg-white/[0.02] border border-white/5 rounded-2xl text-white outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                placeholder="e.g. London, UK"
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] ml-1">Biography</label>
            <textarea
              {...register('biography')}
              rows={5}
              className="w-full px-6 py-5 bg-white/[0.02] border border-white/5 rounded-[2rem] text-white outline-none focus:border-white/20 transition-all resize-none font-serif italic leading-relaxed placeholder:text-zinc-800"
              placeholder="Document the life and legacy of this individual..."
            />
          </div>
        </form>

        <div className="p-8 bg-white/[0.01] border-t border-white/5 flex gap-4">
          <button
            onClick={onClose}
            className="flex-1 py-4 px-6 bg-white/[0.03] hover:bg-white/[0.06] text-zinc-400 hover:text-white text-xs font-black uppercase tracking-widest rounded-2xl transition-all"
          >
            Discard
          </button>
          <button
            onClick={handleSubmit(onSubmit)}
            disabled={loading}
            className="flex-[2] py-4 px-6 disabled:opacity-50 text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl transition-all flex items-center justify-center gap-3 transform hover:-translate-y-0.5 active:translate-y-0"
            style={{ backgroundColor: primaryColor, boxShadow: `0 10px 30px -5px ${primaryColor}4d` }}
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin" size={18} />
                Archiving...
              </>
            ) : (
              <>
                <Save size={18} />
                {editingMember ? 'Update Record' : 'Commit to History'}
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
};
