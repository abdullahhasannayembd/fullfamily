import React from 'react';
import { FamilyMember } from '../types';
import { Calendar, Briefcase, FileText, User, Heart, Trash2, Edit2, X } from 'lucide-react';
import { db, auth } from '../firebase';
import { deleteDoc, doc, writeBatch, collection } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  member: FamilyMember;
  members: FamilyMember[];
  onClose: () => void;
  onEdit: (member: FamilyMember) => void;
  onDelete: () => void;
  primaryColor?: string;
}

export const MemberProfile: React.FC<Props> = ({ member, members, onClose, onEdit, onDelete, primaryColor = "#10b981" }) => {
  const father = members.find(m => m.id === member.fatherId);
  const mother = members.find(m => m.id === member.motherId);
  const spouse = members.find(m => m.id === member.spouseId);

  const handleDelete = async () => {
    if (window.confirm(`Are you sure you want to delete ${member.fullName}?`)) {
      try {
        const batch = writeBatch(db);
        
        // 1. Delete the member
        batch.delete(doc(db, 'members', member.id));
        
        // 2. Clear references in other members
        members.forEach(m => {
          const updates: any = {};
          let hasUpdates = false;
          
          if (m.fatherId === member.id) {
            updates.fatherId = '';
            hasUpdates = true;
          }
          if (m.motherId === member.id) {
            updates.motherId = '';
            hasUpdates = true;
          }
          if (m.spouseId === member.id) {
            updates.spouseId = '';
            hasUpdates = true;
          }
          
          if (hasUpdates) {
            batch.update(doc(db, 'members', m.id), {
              ...updates,
              updatedAt: Date.now()
            });
          }
        });
        
        await batch.commit();
        onDelete();
      } catch (err) {
        console.error("Error deleting member:", err);
        alert("Failed to delete member. Check console for details.");
      }
    }
  };

  const isAdmin = !!auth.currentUser;
  const canEdit = isAdmin || (auth.currentUser?.uid === member.createdBy);

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed top-0 right-0 h-full w-full max-w-md bg-black/40 backdrop-blur-3xl border-l border-white/5 shadow-2xl z-40 flex flex-col"
    >
      <div className="relative h-80 overflow-hidden">
        {member.photoUrl ? (
          <img src={member.photoUrl} alt={member.fullName} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-[#09090b] flex items-center justify-center">
            <User size={80} className="text-zinc-800" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/20 to-transparent" />
        
        <div className="absolute top-8 left-8 flex gap-2">
          {member.status === 'pending' && (
            <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full backdrop-blur-md">
              <span className="text-[9px] font-black text-amber-500 uppercase tracking-[0.2em]">Pending Approval</span>
            </div>
          )}
        </div>

        <button 
          onClick={onClose}
          className="absolute top-8 right-8 p-2.5 bg-black/40 hover:bg-black/60 backdrop-blur-md rounded-xl text-white border border-white/10 transition-all"
        >
          <X size={20} />
        </button>

        <div className="absolute bottom-8 left-10 right-10">
          <h2 className="text-4xl font-black text-white tracking-tighter leading-none mb-3 font-serif italic">{member.fullName}</h2>
          <div className="flex items-center gap-3">
            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: primaryColor }} />
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400">
              {member.occupation || 'Family Member'}
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-10 space-y-12 custom-scrollbar">
        {/* Quick Info Grid */}
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Birth Date</p>
            <div className="flex items-center gap-3 text-white font-mono text-sm">
              <Calendar size={14} className="text-zinc-500" />
              {member.dateOfBirth || 'Unknown'}
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Status</p>
            <div className="flex items-center gap-3 text-white font-mono text-sm">
              <Heart size={14} className="text-zinc-500" />
              {spouse ? 'Married' : 'Single'}
            </div>
          </div>
        </div>

        {/* Family Connections */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">Lineage</h3>
            <div className="w-12 h-[1px] bg-white/5" />
          </div>
          <div className="space-y-3">
            {father && (
              <div className="flex items-center justify-between p-4 bg-white/[0.02] rounded-xl border border-white/5">
                <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Father</span>
                <span className="text-sm font-bold text-white">{father.fullName}</span>
              </div>
            )}
            {mother && (
              <div className="flex items-center justify-between p-4 bg-white/[0.02] rounded-xl border border-white/5">
                <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Mother</span>
                <span className="text-sm font-bold text-white">{mother.fullName}</span>
              </div>
            )}
            {spouse && (
              <div className="flex items-center justify-between p-4 bg-white/[0.02] rounded-xl border border-white/5">
                <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Spouse</span>
                <span className="text-sm font-bold text-white">{spouse.fullName}</span>
              </div>
            )}
            {!father && !mother && !spouse && (
              <p className="text-xs text-zinc-600 italic font-serif">No immediate relatives recorded in this branch.</p>
            )}
          </div>
        </div>

        {/* Biography */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">Biography</h3>
            <div className="w-12 h-[1px] bg-white/5" />
          </div>
          <div className="relative">
            <FileText size={40} className="absolute -top-4 -left-4 text-white/[0.02] pointer-events-none" />
            <p className="text-sm text-zinc-400 leading-relaxed font-serif italic indent-4">
              {member.biography || 'No historical records or personal biography available for this member.'}
            </p>
          </div>
        </div>
      </div>

      {canEdit && (
        <div className="p-8 bg-black/20 backdrop-blur-2xl border-t border-white/5 flex gap-4">
          <button
            onClick={() => onEdit(member)}
            className="flex-1 py-4 px-6 text-white text-xs font-black uppercase tracking-widest rounded-xl shadow-2xl transition-all flex items-center justify-center gap-3 transform hover:-translate-y-0.5 active:translate-y-0"
            style={{ backgroundColor: primaryColor, boxShadow: `0 10px 30px -5px ${primaryColor}4d` }}
          >
            <Edit2 size={16} />
            Edit Profile
          </button>
          <button
            onClick={handleDelete}
            className="p-4 bg-white/[0.03] hover:bg-red-500/10 text-zinc-500 hover:text-red-500 border border-white/5 hover:border-red-500/20 rounded-xl transition-all"
          >
            <Trash2 size={18} />
          </button>
        </div>
      )}
    </motion.div>
  );
};
