# AncestryFlow - Modern Family Tree Application

AncestryFlow is a sophisticated family tree visualization and management tool built with React, D3.js, and Firebase.

## Features

- **Dynamic Tree Visualization**: Automatically generates a hierarchical family tree using D3.js.
- **Secure Authentication**: User login and signup powered by Firebase Authentication.
- **Real-time Collaboration**: Changes are synced instantly across all users via Firestore.
- **Media Support**: Upload and store family member photos using Firebase Storage.
- **Rich Profiles**: Detailed member information including biography, occupation, and relationships.
- **Responsive Design**: Modern, dark-themed UI that works on all devices.

## Firebase Setup Instructions

To get this application running with your own Firebase project, follow these steps:

1. **Create a Firebase Project**: Go to the [Firebase Console](https://console.firebase.google.com/) and create a new project.
2. **Enable Authentication**: 
   - Go to "Authentication" > "Get Started".
   - Enable the "Email/Password" sign-in provider.
3. **Create a Firestore Database**:
   - Go to "Firestore Database" > "Create Database".
   - Start in "Test Mode" or set rules to allow authenticated users to read/write.
4. **Enable Storage**:
   - Go to "Storage" > "Get Started".
   - Set rules to allow authenticated users to upload files.
5. **Get Configuration**:
   - Go to "Project Settings" (gear icon).
   - Under "Your apps", click the web icon (</>) to register a new web app.
   - Copy the `firebaseConfig` object values.
6. **Configure Environment Variables**:
   - Create a `.env` file in the root directory (or use the AI Studio Secrets panel).
   - Add the following variables with your Firebase values:
     ```env
     VITE_FIREBASE_API_KEY=your_api_key
     VITE_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
     VITE_FIREBASE_PROJECT_ID=your_project_id
     VITE_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
     VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
     VITE_FIREBASE_APP_ID=your_app_id
     ```

## Example Database Structure (Firestore)

The application uses a collection named `members`. Each document in this collection has the following structure:

```json
{
  "fullName": "John Doe",
  "fatherId": "parent_doc_id_1",
  "motherId": "parent_doc_id_2",
  "spouseId": "spouse_doc_id",
  "dateOfBirth": "1980-05-15",
  "occupation": "Software Engineer",
  "biography": "A brief history of John...",
  "photoUrl": "https://firebasestorage.googleapis.com/...",
  "createdBy": "user_uid_123",
  "createdAt": 1709823456789,
  "updatedAt": 1709823456789
}
```

## Deployment Instructions (Firebase Hosting)

1. **Install Firebase CLI**: `npm install -g firebase-tools`
2. **Login**: `firebase login`
3. **Initialize**: `firebase init hosting`
   - Select your project.
   - Set `dist` as the public directory.
   - Configure as a single-page app: `Yes`.
4. **Build**: `npm run build`
5. **Deploy**: `firebase deploy`

## Technologies Used

- **Frontend**: React 19, Tailwind CSS 4, D3.js, Motion, Lucide React.
- **Backend**: Firebase (Auth, Firestore, Storage).
- **Forms**: React Hook Form, Zod.
